LPARTH=`pwd`

clear 
echo "Confirm your Network System "



select planet in "Same-network" "Out-of-Network" "back"

do
if [ "$planet" == Same-network ]

then
 bash $LPARTH/sys/windows.sh

elif [ "$planet" == Out-of-Network ]
then
     bash $LPARTH/oon/wn.sh

elif [ "$planet" == back ]
then
   bash $LPARTH/hackexploit.sh




fi
done
