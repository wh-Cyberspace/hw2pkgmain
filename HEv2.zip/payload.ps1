pOwErShElL -noP -wIN 1 -nOnI -eN 
