

#!/bin/bash











LPARTH=`pwd`
RED=$'\e[1;31m'
GREEN=$'\e[1;32m'
YELLOW=$'\e[1;33m'
BLUE=$'\e[1;34m'
RESTORE=$'\e[0m'
chmod 777 *

apt-get install tor -y

clear

#logo or name
	echo "${GREEN} WELCOME TO The ${RESTORE}"
	echo "${RESTORE}"
	echo "${YELLOW}"

echo "                                                                                                          "     
echo " ██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗     ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗"
echo " ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝"
echo " ███████║███████║██║     █████╔╝ █████╗  ██████╔╝    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║   "
echo " ██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║   "
echo " ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║   "
echo " ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   "
echo "                                                                                                          "
echo "${RESTORE}"
egrep -i ver toolinfo;

echo "${RED}=============================================================================================================="
echo "${RESTORE}"

sleep 1.5;
service tor stop
echo "${BLUE}"
echo "LEGAL DISCLAIMER >>"
echo "${RED}"
echo "Do not attempt to violate the law with anything contained here. If this "
echo "is your intention, then LEAVE NOW! Neither administration of this "
echo "server, the authors of this material, or anyone else affiliated in any "
echo "way, is going to accept responsibility for your actions."
echo ""
echo "${RED}=============================================================================================================="
echo "${RESTORE}"
 echo "${RESTORE}"

echo "Select Your target Option >"
echo "${YELLOW}"
	select planet in  "android" "windows" "mac" "Back"${RESTORE}



	do
	if [ "$planet" == android ]

		then
 		bash $LPARTH/netac.sh

	 elif [ "$planet" == windows ]
		then
   		bash $LPARTH/netwc.sh

	 elif [ "$planet" == mac ]

		then 

		bash $LPARTH/netmh.sh

	else [ "$plant" == Back ]

	
		bash $LPARTH/favourite-choice.sh

fi

done

