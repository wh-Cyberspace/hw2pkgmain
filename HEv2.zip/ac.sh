LPARTH=`pwd`
clear 
echo "Confirm your Network System "



select planet in "Same-network" "Out-of-Network" "back"

do
if [ "$planet" == Same-network ]

then
 bash $LPARTH/sys/android.sh

elif [ "$planet" == Out-of-Network ]
then
     bash $LPARTH/oon/an.sh

elif [ "$planet" == back ]
then
   bash $LPARTH/hackexploit.sh




fi
done
